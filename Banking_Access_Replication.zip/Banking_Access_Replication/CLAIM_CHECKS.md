# Claim checks

| Manuscript claim | Evidence and check | Limit on inference |
|---|---|---|
| EU dates span January to October 2016. | Legal ledger rows for Melli, Persia, Sepah and Saderat. Check date of application, date of publication and expiry boundary independently. | These dates concern the specified EU schedule. Saderat's U.S. listing continued. |
| Reported UK milestones come 2, 296, 97 and 111, and 691 days after the relevant EU date. | Legal ledger locates each audited account or company disclosure. The executable rebuild checks the elapsed calendar days. 23 October as the first full day yields 690 for Saderat. | Underlying regulator letters are unavailable. These are different supervisory milestones. |
| Persia reported June 2016 TARGET2 entry before 7 November permission for normal business. Sterling was still limited in 2017. | Companies House 2016 and 2017 reports, and issuer Pillar 3 as at 31 March 2021, p. 5 §1. Ledger records dates, source locators and report dates. | First transaction and the exact scope of the PRA letter remain unobserved. |
| Bundesbank directly lists three of the four UK banks on 10 July 2018. | Bundesbank roster PDF pp. 1, 4, 5. Sepah, Melli, Persia. Distinguish Bank Saderat PLC from the named Iranian and German entities. | Independently observed infrastructure membership on one date. |
| Every bank's latest pre-announcement customer loan balance was below its 2015 level. | bank_endpoints/outputs/bank_pre_withdrawal_summary.csv. Recompute bank ratios from the 16 bank-year panel and check the four alternative 2017-labelled fiscal endpoints. Check ratio to total assets. | Whole-bank carrying values with actual annual endpoints. Some reports were filed later. |
| Melli's 2018 gross carrying amount rose while the net stock fell. | bank_endpoints/outputs/melli_loan_reconciliation_checked.csv. Check note 7, p. 27 and tie gross less provisions to each net value. | Both measures are stocks. Timing covers the reversal of U.S. policy. |
| In 2016 adjusted cross-border claims fell by USD814.357m while liabilities rose by USD2,998.032m. | bis_new/outputs/bis_annual_paired_positions.csv. Independently sum the four quarters. Preserve the original observation precision. Check each sector total after including the unallocated sector. | Residence-based BIS reporters and Iran-resident counterparties. No bank-specific attribution, gross flows or inference to access from a liability increase alone. |
| Euro liability increases exceed the aggregate in 2016. | Frozen BIS denomination series. USD4,809.172m in euros with offsets from some other currencies. Loans and deposits and bank-sector figures are separate breakdowns. | These dimensions remain separate. Currency denomination does not identify the clearing route. |
| GSDB R5/FS records 18/10/5/1. The Allen–Webb Iran indicators are zero. IST has eight Iran cases, zero 2016 formal ends. | crosswalk/outputs/iran_endpoint_crosswalk.csv. Run from hashed original source bytes or use the frozen output verification. Check the exact target label in GSDB and country code 630 in the two other releases. | Distinct country and case endpoint definitions. The results imply no error in a source or common bank treatment. |

## Added evidence and adversarial checks

| Objection | Check and result | Limit in the manuscript |
|---|---|---|
| Germany or the first quarter alone generated the rise in aggregate liabilities. | The two public BIS extracts agree in all eight quarters. Subtracting Germany leaves $508.567 million. Excluding Germany and Q1 together leaves a fall of $811.326 million. Omitting any one quarter preserves both aggregate signs. The smallest liability increase is $122.291 million without the first quarter. | The sign comparison survives the quarter omissions. Magnitude is sensitive to window and geography. |
| The UK country total identifies the four banks or connects the German change to a particular euro clearing route. | The public UK series rises by $10.356 million. BIS locational statistics aggregate by residence. The public reporter, sector and currency breakdowns are separate. | Contributions can offset within the UK total. Country totals leave individual banks and routes unobserved. |
| Lower cash and higher placements prove a transfer of cash to counterparties. | The filed statements and ledger record the two lines. Both directions hold in the common 2017-labelled comparison. | The evidence records positions. Cash definitions vary and the funding flows and counterparties remain unresolved. |
| The same permissions or dollar restrictions applied to the four named banks. | The legal instruments, bank disclosures, roster, and historical OFAC notices identify different decisions and scopes. The supervisory timing rules classify the dates using both bounds. | The UK milestones describe reported decisions with different scope. Roster presence is direct participation at a snapshot. UK access leaves actual dollar activity and payment routes unresolved. |
| Persia's fee expenses establish use of its ordinary correspondent route, and customer loan stocks establish that no new credit was extended. | Both operating reviews attribute commissions to a euro transfer during constraints on the usual correspondent arrangements. Melli's accounting note reconciles an increase in gross balances with a fall in net loans. | Persia's route and the banks' gross originations remain unobserved. |

The two prose files consume generated numbers, and the ledgers record the cells and checks that produce them. All five reported dates enter the timing comparison. None enters an econometric estimating sample.

## Comparative institutional claims

| Claim | Source and audit | Scope |
|---|---|---|
| Melli and Persia shared an EU removal date and reported different supervisory acts | EU application notice and generated milestone table, verified from filed accounts and disclosures | These acts cannot be treated as equivalent approvals or used to estimate a relative speed of supervision. |
| Persia reported euro clearing and no sterling arrangement with a major British bank | Persia 2017 filed chairman's statement, PDF p. 3, with the dated operations entry and separately sourced normal-business permission | The statement identifies a constraint and leaves alternative sterling arrangements and payment volumes unresolved. |
| Hong Kong cited earlier European and British relief. Melli reported access to local clearing before reporting the return of services | HKMA notice and Melli filing, legal ledger records hkma_melli_removal, hk_chats_access and hk_service_resumption. Body claims recompute the month-based bounds from the exact Hong Kong authority date | The reported service resumption does not date a first customer transaction. |
| Persia reported that Dubai remained inactive and cited a lack of a reliable correspondent relationship | DFSA alert on the scope of the EU asset freeze, and Persia 2017 and 2018 filed reports, PDF p. 3. The 2017 filing supplies the stated reason. | The filing gives the bank's account. A branch-specific reopening decision and transaction-level evidence are unavailable. |
| Attribution stops at each reporting population | The bank panel includes 16 statements for four British-incorporated subsidiaries. The branch histories add zero bank-year observations, and BIS totals have no bank linkage. | Descriptive evidence within one episode. |


## Trade-finance evidence

The two Melli filings are separate vintages. The 2017 filing gives two endpoints for refinancing commitments and reports an explicit nil entry for 2016. The 2018 filing reports a broader line and its prior-year comparator. The numerical ledger verifies both vintages against the filed source locators and distinguishes pre-announcement commitments from the broader later line. The qualitative source register gives the PDF pages, observation periods, file hashes and limits for the Melli, Persia and Sepah disclosures. The evidence cannot establish applications, disbursements, shipment values or the identity of the firms served. No additional bank-year rows are added to the financial sample.

## Verification of the evidence added in rev8 (21 November 2026)

The five filings (SHA-256 equal to the download manifest) were read page by page from 300-dpi images.

| Source | Result |
|---|---|
| Melli 2017 filing, note 17, PDF p. 29 | Undrawn commitments relating to letter-of-credit refinancing facilities: EUR36,000,000 at 31 December 2017 (2016: nil). Matches. |
| Melli 2018 filing, note 18, PDF p. 33 | Undrawn commitments relating to letter-of-credit refinancing and discounting facilities: EUR129,284,000 at 31 December 2018 (2017: EUR36,000,000). Matches. |
| Melli 2017 filing, PDF pp. 4 and 15 | Trade-finance facilities and transactions negotiated in 2017 were concluded in the first quarter of 2018; the Hong Kong branch resumed banking services in September 2017; loans and advances to customers EUR16,746k (2016: EUR22,608k). Match. |
| Melli 2018 filing, PDF pp. 4-5 | The bank advised letters of credit, refinanced letters of credit under agreements with Iranian banks and discounted Iranian-bank letters under a facility with an EU-based customer; SWIFT's withdrawal stopped use of the TARGET2 account until internet access restored euro payments. The manuscript now includes advising. |
| Persia 2017 filing, PDF pp. 3 and 6 | No sterling clearing arrangement with any major UK bank; the Dubai branch not reactivated for lack of a reliable correspondent relationship, a main concern of local regulators; commission payable entirely due to a euro transfer. Match. |
| Persia 2018 filing, PDF pp. 3-5 | Trade finance ceased in July 2011 and partly resumed in 2017-18; full resumption depends on correspondent relationships; the Dubai branch remains inactive; commission payable as reported. **Correction:** the package's statement that the report describes "few substantial new transactions" has no basis on these pages; the manuscript now reports what the filing says (small trade-finance fee income, loan repayments, new corporate lending deferred). **Addition:** the report names money-market placements as the largest asset class and places a significant portion of short-term funds with the Central Bank of Iran and some banks in Iran, which bears on the cash-and-advances comparison. |
| Sepah 2018 filing, PDF p. 4 | First international payments and trade transactions in 2017, in euros, through direct participation in TARGET2. Matches. |
| HKMA release of 24 June 2016; DFSA alert (2010); IMF Country Report 17/63, p. 6 | Re-read online. Match. |

banking/development_evidence_register.csv and banking/melli_trade_finance_commitments.csv carry the check date; body_claims.py refuses rows without it.

## Comparative Economic Studies abstract

| Claim | Check |
|---|---|
| Relief began in 2016 and the study follows four British subsidiaries. | The EU application date for Melli and Persia and the four named banks in the legal ledger and the 16-report accounts panel. |
| Persia reported euro clearing before broader permission and still lacked sterling clearing through a major British bank. | The 2017 filing, PDF p. 3, dates the euro arrangement and describes the sterling constraint. The 2021 Pillar 3 disclosure supplies the normal-business permission date. Each statement dates its own event. |
| Customer loans stood at 31–84 percent of 2015 levels at the last pre-announcement endpoints. | Table 2 and the raw report transcription. The four ratios use each bank's own 2015 balance and the last report endpoint strictly before 8 May 2018. The separate recomputation checks the rounded range. |
| Adjusted cross-border claims fell by $0.81 billion and liabilities rose by $3.00 billion in 2016. | Table 3 and the four quarterly BIS observations for each of the two reported totals. The series are exchange-rate- and break-adjusted. |
| Payments access and outstanding credit followed different paths. | The dated reports establish the return of selected services and the accounts establish lower outstanding loans at all four banks. The samples give no direct measure of gross lending or payment volume. |

The comparison with reimposition uses Melli's own description of the interruption and restoration of euro payments. The overlapping currency and authority observations give the order of events, with comparative speeds and the effect of relief on lending outside the scope of the design.


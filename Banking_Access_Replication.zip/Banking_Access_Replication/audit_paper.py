"""Generate manuscript values, provenance and the named-sample robustness checks."""
import csv
import json
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'generated'
PANEL = 'banking/bank_year_panel.csv'
ENDPOINTS = 'bank_endpoints/outputs/bank_pre_withdrawal_summary.csv'
BIS = 'bis_new/outputs/bis_quarterly_paired_positions.csv'
ANNUAL = 'bis_new/outputs/bis_annual_paired_positions.csv'
LEGAL = 'legal_new/primary_source_legal_and_access_ledger.csv'
CROSSWALK = 'crosswalk/outputs/iran_endpoint_crosswalk.csv'


def check_counts(label, frame, expected):
    counts = frame.count().to_dict()
    print(label, counts)
    assert len(frame) == expected and set(counts.values()) == {expected}


def supervisory_timing(legal):
    """Classify each reported milestone by calendar year relative to EU removal."""
    records = {
        'pra_no_objection': 'melli_eu_delisting',
        'persia_pra_2016': 'persia_eu_delisting',
        'sepah_2016_19': 'sepah_eu_delisting',
        'sepah_2017_20': 'sepah_eu_delisting',
        'saderat_2018_15': 'saderat_eu_expiry_2016',
    }
    labels = {
        'earlier': r'Before \(t-1\)', 't-1': r'\(t-1\)', 't': r'\(t\)',
        't+1': r'\(t+1\)', 'later': r'After \(t+1\)', 'unresolved': 'Unresolved',
    }

    def classify(year):
        if year < -1:
            return 'earlier'
        if year > 1:
            return 'later'
        return {-1: 't-1', 0: 't', 1: 't+1'}[year]

    rows = []
    for event, anchor in records.items():
        anchor_date = legal.at[anchor, 'event_date_lower']
        assert anchor_date == legal.at[anchor, 'event_date_upper']
        assert anchor_date == legal.at[event, 'comparison_anchor_date']
        t = pd.Timestamp(anchor_date).year
        lower, upper = pd.to_datetime(legal.loc[event, ['event_date_lower', 'event_date_upper']])
        category = 'unresolved'
        if pd.notna(lower) and pd.notna(upper):
            assert lower <= upper
            if classify(lower.year-t) == classify(upper.year-t):
                category = classify(lower.year-t)
        rows.append({'event_record_id': event, 'anchor_record_id': anchor,
                     'anchor_year': t, 'first_possible_date': lower,
                     'last_possible_date': upper, 'relative_year_class': category,
                     'estimating_sample': 0})
    timing = pd.DataFrame(rows).set_index('event_record_id')
    assert timing.index.is_unique and set(timing.relative_year_class) <= set(labels)
    assert timing.at['sepah_2016_19', 'relative_year_class'] == 't'
    assert timing.at['sepah_2017_20', 'relative_year_class'] == 't'
    assert timing.at['saderat_2018_15', 'relative_year_class'] == 'later'
    counts = timing.relative_year_class.value_counts().reindex(labels, fill_value=0)
    assert counts.sum() == len(records)
    timing.to_csv(OUT/'supervisory_timing.csv')
    counts.rename('milestone_count').to_csv(OUT/'supervisory_timing_counts.csv')
    lines = [r'\begin{table}[!htbp]',r'\centering\small',
             r'\caption{Calendar timing of reported UK milestones relative to EU removal or expiry}',
             r'\begin{tabular}{@{}lr@{}}',r'\toprule',
             r'Relative calendar year & Reported milestones \\',r'\midrule']
    lines.extend(f'{labels[key]} & {counts[key]} '+r'\\' for key in labels)
    lines.extend([r'\bottomrule',r'\end{tabular}',r'\par\smallskip\footnotesize',
                  r'The sample contains the five company-reported milestones in the main comparison.',
                  r'Sepah contributes two milestones. The timing classes refer to dates of reported events.',
                  r'\end{table}'])
    (OUT/'supervisory_timing_table.tex').write_text('\n'.join(lines)+'\n')


def main():
    OUT.mkdir(exist_ok=True)
    panel = pd.read_csv(ROOT / PANEL, parse_dates=['fiscal_end'])
    e = pd.read_csv(ROOT / ENDPOINTS).set_index('bank')
    legal = pd.read_csv(ROOT / LEGAL).set_index('record_id')
    annual = pd.read_csv(ROOT / ANNUAL)
    raw = pd.read_csv(ROOT / BIS)
    xr = pd.read_csv(ROOT / CROSSWALK).set_index('check').value
    supervisory_timing(legal)
    sample = panel[['bank', 'fiscal_year', 'fiscal_end', 'loans_advances_customers']]
    check_counts('customer loan panel', sample, 16)
    assert not sample.duplicated(['bank', 'fiscal_year']).any()
    trigger = pd.Timestamp(legal.at['us_withdrawal_announcement', 'event_date_lower'])
    assert trigger == pd.Timestamp('2018-05-08')
    loans = []
    for bank, group in sample.groupby('bank'):
        baseline = group.loc[group.fiscal_year.eq(2015)].iloc[0]
        latest = group.loc[group.fiscal_end.lt(trigger)].sort_values('fiscal_end').iloc[-1]
        yr17 = group.loc[group.fiscal_year.eq(2017)].iloc[0]
        r2017 = 100 * yr17.loans_advances_customers / baseline.loans_advances_customers
        final = 100 * latest.loans_advances_customers / baseline.loans_advances_customers
        assert abs(e.at[bank, 'loan_stock_2017_pct_of_2015'] - r2017) < 1e-8
        assert abs(e.at[bank, 'loan_stock_last_pre_pct_of_2015'] - final) < 1e-8
        assert latest.fiscal_end.date().isoformat() == e.at[bank, 'last_fiscal_endpoint_before_us_withdrawal']
        loans.append((bank, final, r2017))
    assert len(loans) == 4 and all(a < 100 and b < 100 for _, a, b in loans)
    statuses = {'melli': 'melli_bbk_target2_snapshot', 'persia': 'persia_bbk_target2_snapshot',
                'saderat': 'saderat_bbk_target2_distinction', 'sepah': 'sepah_bbk_target2_snapshot'}
    roster = legal.loc[list(statuses.values())]
    assert roster.event_date_lower.eq('2018-07-10').all()
    assert roster.event_date_upper.eq('2018-07-10').all()
    assert roster.stage.eq('infrastructure_roster').sum() == 3
    assert roster.stage.eq('infrastructure_roster_exact_name').sum() == 1
    permissions = legal.loc[['melli_eu_delisting', 'persia_eu_delisting',
                             'sepah_eu_delisting', 'saderat_eu_expiry_2016']]
    assert permissions.event_date_lower.nunique() == 3
    assert permissions.event_date_lower.eq(permissions.event_date_upper).all()
    assert legal.at['persia_2016_06', 'event_date_lower'] == '2016-06-01'
    assert legal.at['persia_2016_06', 'event_date_upper'] == '2016-06-30'
    assert legal.at['persia_pra_2016', 'event_date_lower'] == '2016-11-07'
    assert legal.at['persia_2017_07', 'event_date_upper'] == '2017-06-23'
    assert all(xr[k] == v for k, v in {
        'iran_recorded_case_endings_2016': 18, 'iran_ending_financial_cases_2016': 10,
        'iran_ending_financial_services_cases_2016': 5, 'iran_ending_payment_infrastructure_cases_2016': 1,
        'iran_lifting_pulses_2015_2018': 0, 'iran_imposition_pulses_2015_2018': 0,
        'iran_target_cases': 8, 'iran_formal_terminations_2016': 0}.items())
    groups = ['claims_total', 'liabilities_total', 'liabilities_banks', 'liabilities_eur']
    data = raw.loc[raw.L_MEASURE.eq('F') & raw.quarter.str.startswith('2016')
                   & raw.series.isin(groups), ['quarter', 'series', 'OBS_VALUE']]
    check_counts('adjusted changes prior to reshape', data, 16)
    wide = data.pivot(index='quarter', columns='series', values='OBS_VALUE')
    check_counts('adjusted changes after reshape', wide, 4)
    total = wide.sum()
    yr = annual.loc[annual.measure.str.startswith('sum')].set_index(['series', 'year']).value
    for s in groups:
        assert abs(total[s] - yr[s, 2016]) < .001
    sensitivity = (total - wide).round(3)
    assert sensitivity.claims_total.lt(0).all() and sensitivity.liabilities_total.gt(0).all()
    sensitivity.rename_axis('excluded_quarter').to_csv(OUT / 'bis_2016_exclude_quarter.csv')

    def emit_value(name, value, source, actual_cell, check, inference):
        values.append(dict(macro=name, display=str(value), file=source,
                           record_or_cell=actual_cell, test=check, limit=inference))

    values = []
    emit_value('BankCount', 'four', PANEL, 'unique bank', '16 unique bank-year rows', 'Named frame')
    emit_value('FilingCount', len(panel), PANEL, 'bank and fiscal_year', 'four banks with four filings each', 'One fiscal statement per bank-year')
    emit_value('ReliefYear', permissions.event_date_lower.iloc[0][:4], LEGAL, 'four EU records in permissions', 'three exact EU dates', 'EU listing perimeter')
    emit_value('RosterCount', 'three', LEGAL, 'four Bundesbank roster records', 'three direct listings and one name absent', 'One observation date. Indirect access unresolved.')
    emit_value('RosterDate', 'July 2018', LEGAL, 'three bank snapshot rows, date=2018-07-10', 'exact common date', 'Roster membership alone')
    emit_value('PersiaClearing', 'June 2016', LEGAL, 'persia_2016_06 event bounds', 'latest clearing bound precedes permission', 'Company-reported month')
    emit_value('PersiaPermission', '7 November 2016', LEGAL, 'persia_pra_2016', 'exact issuer date', 'Original letter unavailable')
    emit_value('PersiaSterling', 'June 2017', LEGAL, 'persia_2017_07 upper bound', 'report date', 'Company reported sterling clearing unavailable at reporting')
    emit_value('WithdrawalDate', trigger.strftime('%d %B %Y').lstrip('0'), LEGAL, 'us_withdrawal_announcement', 'endpoints strictly earlier', 'No inference to anticipation')
    emit_value('BaseYear', min(sample.fiscal_year), PANEL, 'fiscal_year', 'one baseline per bank', 'March and December endpoints')
    emit_value('CheckYear', 2017, PANEL, 'fiscal_year', 'all latest balances and labelled 2017 below benchmark', 'Removes dependence on March 2018 values')
    low, high = min(a for _, a, _ in loans), max(a for _, a, _ in loans)
    emit_value('LoanRange', f'{low:.0f}--{high:.0f}', ENDPOINTS, 'loan_stock_last_pre_pct_of_2015', 'recompute four ratios from current-year amounts', 'Carrying values, no origination')
    for macro, name in [('ClaimsFall','claims_total'), ('LiabilityRise','liabilities_total')]:
        emit_value(macro, rf'\${abs(total[name])/1000:.2f} billion', ANNUAL, f'{name}, 2016, adjusted change',
                   'sum four quarterly changes and compare annual output', 'BIS reporting offices, not the four banks')
    emit_value('LiabilityLow', rf'\${sensitivity.liabilities_total.min():.0f} million', 'generated/bis_2016_exclude_quarter.csv',
               '2016Q1 excluded, liabilities_total', 'minimum over four 3-quarter sums', 'Tests single-quarter dependence of sign only')
    emit_value('LiabilityHigh', rf'\${sensitivity.liabilities_total.max()/1000:.2f} billion', 'generated/bis_2016_exclude_quarter.csv',
               '2016Q2 excluded, liabilities_total', 'maximum over four 3-quarter sums', 'Does not establish persistence or causality')
    macros = {row['macro']: row['display'] for row in values}
    assert total.liabilities_banks > total.liabilities_total > 0
    assert legal.at['persia_2016_06', 'event_date_upper'] < legal.at['persia_pra_2016', 'event_date_lower']
    recon_path = 'bank_endpoints/outputs/melli_loan_reconciliation_checked.csv'
    recon = pd.read_csv(ROOT / recon_path)
    check_counts('Melli reconciliation observations', recon[['fiscal_year', 'gross_customer_loans_eur_thousand', 'net_customer_loans_eur_thousand']], 2)
    assert recon.sort_values('fiscal_year').gross_customer_loans_eur_thousand.diff().iloc[-1] > 0
    assert recon.sort_values('fiscal_year').net_customer_loans_eur_thousand.diff().iloc[-1] < 0
    emit_value('FindingSector', '2016 liabilities concentrated in bank counterparties', ANNUAL,
               'liabilities_banks and liabilities_total, 2016 adjusted changes',
               'bank-counterparty increase exceeds total', 'Other sector movements partly offset the rise')
    emit_value('FindingQuarterSigns', 'both signs survive each omission', 'generated/bis_2016_exclude_quarter.csv',
               'claims_total and liabilities_total for all four omissions', 'all claims negative, all liabilities positive',
               'Magnitude and persistence remain sensitive to time window')
    emit_value('FindingPersiaOrder', 'reported June clearing precedes normal-business permission', LEGAL,
               'persia_2016_06 and persia_pra_2016', 'upper bound before dated permission', 'First transaction date unresolved')
    emit_value('FindingCarryingValue', 'Melli gross carrying amount rose while net carrying amount fell', recon_path,
               '2017/2018 gross, provisions and net', 'check both signs and published accounting identity',
               'The gross stock is not gross originations')

    emit_value('FindingLoansPreAnnouncement', 'all four pre-announcement loan stocks below their 2015 values', ENDPOINTS,
               'loan_stock_last_pre_pct_of_2015 for all four banks', 'recompute all four ratios using the exact dates',
               'Differences in fiscal month and anticipation remain')
    emit_value('FindingLoansCommonLabel', 'the same direction at the 2017-labelled endpoints', ENDPOINTS,
               'loan_stock_2017_pct_of_2015 for all four banks', 'recompute each 2017 ratio and assert less than 100',
               'Common label only. No common fiscal month or counterfactual.')
    emit_value('FindingRoster', 'exact-name direct participation for three named UK banks', LEGAL,
               ', '.join(statuses.values()), 'matched named entries versus documented exact-name absence',
               'One roster date. First use and indirect access unresolved.')
    # Prose checks (abstract, body and appendix) are in audit_prose.py, after body_claims.py.
    with (OUT / 'paper_claim_ledger.csv').open('w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=values[0].keys())
        writer.writeheader()
        writer.writerows(values)
    content = ''.join(r'\newcommand{\%s}{%s}' % (v['macro'], v['display']) + '\n' for v in values if v['macro'] in macros)
    (OUT / 'paper_claims.tex').write_text(content)
    with (OUT / 'observation_membership.csv').open('w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['bank', 'statement_rows', '2015_baseline', 'latest_pre_withdrawal', '2017_labelled_check', 'direct_Bundesbank_roster_2018_07_10', 'estimating_sample'])
        for name, _, _ in loans:
            found = legal.at[statuses[name], 'stage'] == 'infrastructure_roster'
            writer.writerow([name, 4, 1, 1, 1, 'named' if found else 'exact name absent', 0])
    (OUT / 'paper_qa_counts.json').write_text(json.dumps({
        'bank_years': 16, 'BIS_quarters_per_series': 4,
        'econometric_estimating_samples': 0, 'roster_sample': 4,
        'GSDB_external_raw_required': True}, indent=2) + '\n')


if __name__ == '__main__':
    main()

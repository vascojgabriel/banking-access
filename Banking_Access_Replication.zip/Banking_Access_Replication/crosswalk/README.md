# Iran sanctions endpoints across three source releases

The sources record different events. The comparison concerns the 2016 change in legal permissions and cannot identify whether a particular bank processed an Iranian payment.

| Source and unit | What the released data record |
|---|---|
| Global Sanctions Data Base Release 5, case | 18 cases with the exact target label Iran have a recorded ending year of 2016. |
| Global Sanctions Data Base Financial Sanctions supplement, instrument flags on a case | A one-to-one join by case identifier places 10 of the 18 in the financial supplement. Five carry the financial-services flag and one carries the payment-service infrastructure flag. The flags can overlap. |
| Allen and Webb, country-year | The four rows for Iran, country code 630, in 2015–2018 have zeroes in both the imposition and lifting fields. These fields record events in this source and do not measure whether sanctions remain in force. |
| Attia and Grauvogel, sender–target case | The public workbook contains 399 cases and eight for target code 630. None of the eight gives 2016 as the formal termination year. The EU and UN nuclear cases, `EU_IRN_07` and `UN_IRN_06`, have both the gradual and ongoing flags set to one. |

The GSDB result uses source case endings, which may end only one component of a broader policy. IST's ongoing flag refers to 31 December 2018. Its gradual flag records gradual scaling back without giving the date of every change. Blank termination years are retained as blank. Nothing in the country-year flags or case fields dates operational bank access.

## Reproduce from source files

This script needs Python 3.10 or later, pandas and openpyxl for source reproduction. The outputs were reproduced with Python 3.12.14, pandas 2.2.3 and openpyxl 3.1.5. Run from this directory.

```bash
python build_crosswalk.py \
  --gsdb-r5 /path/to/GSDB-R5.csv \
  --gsdb-fs /path/to/GSDB-FS.csv \
  --allen-webb /path/to/RecoveringFromEconomicCoercion.dta \
  --ist '/path/to/IST_JPR_Attia&Grauvogel.xlsx' \
  --output reproduced
```

The downloaded names are illustrative. Any local paths work, including paths containing spaces. To download the two public publisher files temporarily, omit their path options and pass `--download-public`. The two GSDB inputs are supplied separately. Original member files are checked against the SHA-256 values in `outputs/provenance.json` before being read. The script checks the unique case identifiers across both complete GSDB files and verifies the fields shared by matched financial cases before taking the Iran subset.

```bash
python build_crosswalk.py --verify-offline
```

The offline command uses only Python's standard library. It verifies the three CSV focus tables and the LaTeX tabular against their recorded hashes and checks the findings above. The tabular uses booktabs and can be included inside a manuscript table. Source reproduction is the preceding command. The package includes GSDB aggregates, the four focus country-year indicators and a minimal IST case crosswalk. It includes no complete original inputs or GSDB case records.

## Source references

- Global Sanctions Data Base, Release 5 and Financial Sanctions supplement. The [data page](https://www.globalsanctionsdatabase.com/data/) identifies the two releases and provides their access form. The [publication page](https://www.globalsanctionsdatabase.com/publications/) lists release history and related citations, including Yotov et al., *Financial Sanctions and International Trade: Insights from New Data*.
- Allen, Susan Hannah, and Clayton McLaughlin Webb (2025), “Recovering from economic coercion: Does the pain stop when sanctions end?”, *Journal of Peace Research* 62(4), 1061–1075. The country code and fields are described in `codebook.xlsx` in the [replication archive](https://cdn.cloud.prio.org/files/d628dfde-a2e4-4cd4-8bf2-d96acec10ce1/AllenWebb_ReplicationFiles.zip). [Article DOI](https://doi.org/10.1177/00223433241273057).
- Attia, Hana, and Julia Grauvogel (2023), “International Sanctions Termination, 1990–2018: Introducing the IST dataset”, *Journal of Peace Research* 60(4), 709–719. Definitions of formal termination, de facto termination, ongoing status and gradual termination are in the codebook included in the [public data deposit](https://doi.org/10.7910/DVN/SVR5W7). [Article DOI](https://doi.org/10.1177/00223433221087080).

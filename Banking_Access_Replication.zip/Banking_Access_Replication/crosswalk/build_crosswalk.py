#!/usr/bin/env python3
"""Reproduce the endpoint comparison for Iran from three source releases."""

import argparse
import csv
import hashlib
import io
import json
from pathlib import Path
import tempfile
from urllib.request import Request, urlopen
from zipfile import ZipFile


IRAN_CODE = 630
CASE_YEAR = 2016
PANEL_YEARS = (2015, 2016, 2017, 2018)

INPUTS = {
    "gsdb_r5": {
        "file": "GSDB-R5.csv",
        "sha256": "ac552dc9eb5d769df45fe007af3c6761c07c638d70865c41e8aa25144c61490a",
        "access": "https://www.globalsanctionsdatabase.com/data/",
    },
    "gsdb_fs": {
        "file": "GSDB-FS.csv",
        "sha256": "c71b7a42628b64145a65add58a13ecd9ef24a8ea46955e39c235851b99705ab5",
        "access": "https://www.globalsanctionsdatabase.com/data/",
    },
    "allen_webb": {
        "file": "RecoveringFromEconomicCoercion.dta",
        "sha256": "a5b7a1876104c201abb38dfdd5e6eff3d780f7bb9b9f515e3acd6bb7286afb59",
        "citation": "https://doi.org/10.1177/00223433241273057",
        "archive": "https://cdn.cloud.prio.org/files/d628dfde-a2e4-4cd4-8bf2-d96acec10ce1/AllenWebb_ReplicationFiles.zip",
    },
    "ist": {
        "file": "IST_JPR_Attia&Grauvogel.xlsx",
        "sha256": "bf3d604aca32d5f432ed9069a1fdae754dd756ca42fd146309025ab329cf7f1e",
        "citation": "https://doi.org/10.1177/00223433221087080",
        "archive": "https://dataverse.harvard.edu/api/access/dataset/:persistentId/?persistentId=doi:10.7910/DVN/SVR5W7",
        "dataset": "https://doi.org/10.7910/DVN/SVR5W7",
    },
}


def check(condition, why):
    if not condition:
        raise ValueError(why)


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def source_summary(gsdb_r5, gsdb_fs):
    import pandas as pd

    r5 = pd.read_csv(gsdb_r5, keep_default_na=False)
    fs = pd.read_csv(gsdb_fs, keep_default_na=False)
    check(len(r5) == 1794 and r5.case_id.is_unique, "Unexpected R5 case universe.")
    check(len(fs) == 1072 and fs.case_id.is_unique, "Unexpected FS case universe.")
    check(set(fs.case_id) == set(r5.loc[r5.financial.eq(1), "case_id"]),
          "GSDB-FS IDs do not match the financial cases in GSDB-R5.")
    keys = ["case_id", "sanctioned_state", "sanctioning_state", "begin_year", "end_year", "financial"]
    check(
        r5.loc[r5.financial.eq(1), keys].sort_values("case_id").reset_index(drop=True)
        .equals(fs[keys].sort_values("case_id").reset_index(drop=True)),
        "Shared GSDB case metadata disagree.",
    )
    focus = r5.loc[r5.sanctioned_state.eq("Iran") & r5.end_year.eq(CASE_YEAR), ["case_id", "financial"]]
    joined = focus.merge(fs[["case_id", "descr_financial"]], on="case_id", how="left", validate="one_to_one")
    matched = joined.financial.eq(1)
    check(joined.descr_financial.notna().eq(matched).all(), "Missing or unexpected FS merge links.")
    check(joined.loc[matched, "descr_financial"].str.strip().ne("").all(), "Missing financial subtype.")
    flags = joined.loc[matched, "descr_financial"].map(
        lambda s: {token.strip() for token in s.split(",") if token.strip()})
    check((~flags.map(lambda s: "payment_service_infrastructure" in s
                     and "financial_services" not in s)).all(),
          "An infrastructure flag is not also a financial-services flag in this subset.")
    return {
        "r5_release_cases": len(r5),
        "fs_release_cases": len(fs),
        "iran_recorded_case_endings_2016": len(joined),
        "iran_ending_financial_cases_2016": int(joined.financial.sum()),
        "iran_ending_financial_services_cases_2016": int(flags.map(lambda s: "financial_services" in s).sum()),
        "iran_ending_payment_infrastructure_cases_2016": int(flags.map(lambda s: "payment_service_infrastructure" in s).sum()),
    }


def country_years(allen_webb):
    import pandas as pd

    indicators = ["ccode", "year", "imposed_sanc", "lifted_sanc"]
    panel = pd.read_stata(allen_webb, columns=indicators, convert_categoricals=False)
    iran = panel.loc[panel.ccode.eq(IRAN_CODE) & panel.year.isin(PANEL_YEARS), indicators].sort_values("year")
    check(tuple(iran.year) == PANEL_YEARS, "Expected one Allen–Webb Iran row for each year from 2015 to 2018.")
    check(iran[["imposed_sanc", "lifted_sanc"]].isin([0, 1]).all().all(),
          "Allen–Webb indicator is missing or not binary.")
    return iran.astype(int).to_dict("records")


def iran_ist_cases(ist):
    import pandas as pd

    selected = ["caseid", "sender", "target", "terdate", "defactoter", "ongoing", "gradual"]
    workbook = pd.read_excel(ist, sheet_name="Tabelle1", usecols=selected, engine="openpyxl")
    check(len(workbook) == 399 and workbook.caseid.is_unique, "Unexpected IST case universe.")
    iran = workbook.loc[pd.to_numeric(workbook.target, errors="coerce").eq(IRAN_CODE)].copy()
    check(iran[["ongoing", "gradual"]].isin([0, 1]).all().all(), "IST Iran flags must be binary.")
    for source, output in (("terdate", "formal_termination_year"), ("defactoter", "de_facto_termination_year")):
        parsed = pd.to_datetime(iran[source], format="%d.%m.%Y", errors="coerce")
        check(parsed.notna().equals(iran[source].notna()), f"Unexpected IST date in {source}.")
        iran[output] = parsed.dt.year.astype("Int64")
    columns = ["caseid", "sender", "target", "formal_termination_year", "de_facto_termination_year", "ongoing", "gradual"]
    rows = iran[columns].sort_values("caseid")
    rows = rows.astype(object).where(rows.notna(), None)
    return len(workbook), rows.to_dict("records")


def make_check_table(gsdb, aw, ist_total, ist):
    records = []
    steps = (
        ("GSDB-R5", "r5_release_cases", "All rows in GSDB-R5"),
        ("GSDB-FS", "fs_release_cases", "All rows in the financial supplement"),
        ("GSDB-R5", "iran_recorded_case_endings_2016", "Exact sanctioned_state Iran and end_year 2016"),
        ("GSDB-R5 / GSDB-FS", "iran_ending_financial_cases_2016", "Financial indicator equals one among the GSDB-R5 Iran endings"),
        ("GSDB-R5 / GSDB-FS", "iran_ending_financial_services_cases_2016", "Financial_services subtype among those endings, linked by case_id"),
        ("GSDB-R5 / GSDB-FS", "iran_ending_payment_infrastructure_cases_2016", "Payment_service_infrastructure subtype among those endings, linked by case_id"),
    )
    records.extend((source, key, gsdb[key], definition) for source, key, definition in steps)
    records.extend([
        ("Allen-Webb", "iran_country_years_2015_2018", len(aw), "Country code 630, calendar years 2015 through 2018"),
        ("Allen-Webb", "iran_imposition_pulses_2015_2018", sum(row["imposed_sanc"] for row in aw), "Sum of imposed_sanc in the four focus years"),
        ("Allen-Webb", "iran_lifting_pulses_2015_2018", sum(row["lifted_sanc"] for row in aw), "Sum of lifted_sanc in the four focus years"),
        ("IST", "ist_release_cases", ist_total, "All records in worksheet Tabelle1"),
        ("IST", "iran_target_cases", len(ist), "Target code 630 in the IST release"),
        ("IST", "iran_formal_terminations_2016", sum(row["formal_termination_year"] == CASE_YEAR for row in ist), "Year of terdate equals 2016 in the Iran target records"),
    ])
    return [dict(zip(("source", "check", "value", "definition"), row)) for row in records]


def verify_findings(summary, aw, ist):
    values = {row["check"]: int(row["value"]) for row in summary}
    expected = {
        "r5_release_cases": 1794,
        "fs_release_cases": 1072,
        "iran_recorded_case_endings_2016": 18,
        "iran_ending_financial_cases_2016": 10,
        "iran_ending_financial_services_cases_2016": 5,
        "iran_ending_payment_infrastructure_cases_2016": 1,
        "iran_country_years_2015_2018": 4,
        "iran_imposition_pulses_2015_2018": 0,
        "iran_lifting_pulses_2015_2018": 0,
        "ist_release_cases": 399,
        "iran_target_cases": 8,
        "iran_formal_terminations_2016": 0,
    }
    check(values == expected, "Crosswalk aggregate findings differ from the audited release.")
    check(tuple(int(row["year"]) for row in aw) == PANEL_YEARS and all(
        int(row["ccode"]) == IRAN_CODE and int(row["imposed_sanc"]) == int(row["lifted_sanc"]) == 0
        for row in aw
    ), "Allen–Webb focus panel does not reproduce.")
    check(len(ist) == 8 and len({row["caseid"] for row in ist}) == 8 and all(
        int(row["target"]) == IRAN_CODE and str(row["formal_termination_year"]) != str(CASE_YEAR)
        for row in ist
    ), "IST Iran case crosswalk does not reproduce.")
    by_id = {row["caseid"]: row for row in ist}
    for caseid in ("EU_IRN_07", "UN_IRN_06"):
        row = by_id[caseid]
        check(int(row["ongoing"]) == int(row["gradual"]) == 1 and row["formal_termination_year"] in (None, ""),
              f"Unexpected IST coding for {caseid}.")


def write_csv(path, records):
    with path.open("w", encoding="utf-8", newline="") as out:
        writer = csv.DictWriter(out, fieldnames=list(records[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(records)


def render_table(summary):
    """Render a compact LaTeX tabular for a manuscript using booktabs."""
    values = {row["check"]: int(row["value"]) for row in summary}
    return r"""\begin{tabular}{@{}lp{0.61\linewidth}@{}}
\toprule
Source and unit & Recorded outcome \\
\midrule
GSDB-R5 case & %(iran_recorded_case_endings_2016)d Iran cases end in 2016. \\
GSDB-FS case flags & %(iran_ending_financial_cases_2016)d financial cases, %(iran_ending_financial_services_cases_2016)d with a financial-services flag, %(iran_ending_payment_infrastructure_cases_2016)d with a payment-infrastructure flag. \\
Allen--Webb country-year & %(iran_imposition_pulses_2015_2018)d imposition events and %(iran_lifting_pulses_2015_2018)d lifting events recorded in 2015--2018. \\
IST sender--target case & %(iran_target_cases)d Iran cases in the release, %(iran_formal_terminations_2016)d formally ending in 2016. Both the EU and UN nuclear cases are gradual and ongoing at the end of 2018. \\
\bottomrule
\end{tabular}
""" % values


def fetch_member(source, destination):
    request = Request(source["archive"], headers={"User-Agent": "Mozilla/5.0"})
    with urlopen(request, timeout=45) as response, ZipFile(io.BytesIO(response.read())) as archive:
        matches = [entry for entry in archive.namelist() if Path(entry).name == source["file"]]
        check(len(matches) == 1, f"Cannot uniquely identify {source['file']} in the publisher archive.")
        destination.write_bytes(archive.read(matches[0]))


def build(args):
    with tempfile.TemporaryDirectory(prefix="sanctions-crosswalk-publisher-") as scratch:
        for key, source in INPUTS.items():
            path = getattr(args, key)
            if path is None and args.download_public and "archive" in source:
                path = Path(scratch) / source["file"]
                fetch_member(source, path)
                setattr(args, key, path)
            check(path is not None and path.is_file(), f"Supply the exact original input {source['file']}.")
            check(sha256(path) == source["sha256"], f"Original-input SHA-256 mismatch for {source['file']}.")
        gsdb = source_summary(args.gsdb_r5, args.gsdb_fs)
        aw = country_years(args.allen_webb)
        total, ist = iran_ist_cases(args.ist)
    summary = make_check_table(gsdb, aw, total, ist)
    verify_findings(summary, aw, ist)

    args.output.mkdir(parents=True, exist_ok=True)
    data = {
        "iran_endpoint_crosswalk.csv": summary,
        "allen_webb_iran_2015_2018.csv": aw,
        "ist_iran_cases.csv": ist,
    }
    for name, rows in data.items():
        write_csv(args.output / name, rows)
    tex = args.output / "table_iran_endpoint_crosswalk.tex"
    tex.write_text(render_table(summary), encoding="utf-8")
    manifest = {"original_inputs": INPUTS, "outputs": {name: sha256(args.output / name) for name in (*data, tex.name)}}
    (args.output / "provenance.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")


def verify_offline(output):
    manifest = json.loads((output / "provenance.json").read_text(encoding="utf-8"))
    names = ("iran_endpoint_crosswalk.csv", "allen_webb_iran_2015_2018.csv", "ist_iran_cases.csv")
    check(manifest["original_inputs"] == INPUTS, "Input provenance differs from the audited releases.")
    tex_name = "table_iran_endpoint_crosswalk.tex"
    check(set(manifest["outputs"]) == {*names, tex_name}, "Output manifest does not cover the expected tables.")
    rows = []
    for name in names:
        table = output / name
        check(sha256(table) == manifest["outputs"][name], f"Output SHA-256 mismatch for {name}.")
        with table.open(encoding="utf-8", newline="") as stream:
            rows.append(list(csv.DictReader(stream)))
    verify_findings(*rows)
    tex = output / tex_name
    check(sha256(tex) == manifest["outputs"][tex_name] and tex.read_text(encoding="utf-8") == render_table(rows[0]),
          "LaTeX table differs from the focus tables.")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--gsdb-r5", type=Path)
    parser.add_argument("--gsdb-fs", type=Path)
    parser.add_argument("--allen-webb", type=Path)
    parser.add_argument("--ist", type=Path)
    parser.add_argument("--download-public", action="store_true", help="Retrieve missing Allen–Webb or IST files from their public publisher archives.")
    parser.add_argument("--verify-offline", action="store_true", help="Check existing focused tables without opening original datasets.")
    parser.add_argument("--output", type=Path, default=Path(__file__).resolve().parent / "outputs")
    args = parser.parse_args()
    if args.verify_offline:
        verify_offline(args.output)
        print("Offline focus tables and their recorded SHA-256 hashes agree.")
    else:
        build(args)
        print("Iran endpoint crosswalk reproduced from the four verified source files.")


if __name__ == "__main__":
    main()

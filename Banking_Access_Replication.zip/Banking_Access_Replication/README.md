# Replication package: banking access after sanctions relief

The package reproduces every number, table and the figure in "Banking access after sanctions relief" (four
UK subsidiaries of Iranian banks, 2015-2018) from filed accounts, legal records and BIS statistics.

## Run

With Python 3.10 or later:

    python -m pip install -r requirements.txt
    python run_all.py

The build stops at the first failed check. Its last step, verify_numbers.py, recomputes the headline numbers
(55 macros and the balance-composition table) without the generators' code.

## Outputs

| In the paper | File | Produced by |
|---|---|---|
| Every number in the text | generated/paper_claims.tex and generated/body_claims.tex (122 LaTeX macros); source cell and check for each in generated/paper_claim_ledger.csv and generated/body_claim_ledger.csv | audit_paper.py, body_claims.py |
| Table 1, EU removal and UK supervisory milestones | generated/table_milestones.tex | body_claims.py |
| Table 2, bank accounts before the US withdrawal announcement | bank_endpoints/outputs/table_bank_pre_withdrawal.tex | bank_endpoints/build_bank_endpoints.py |
| Figure 1, customer loans indexed to 2015 | generated/loan_paths.pdf | run_all.py |
| Tables 3 and 4, cross-border positions vis-a-vis Iran | bis_new/outputs/table_bis_paired_positions.tex, table_bis_reporters.tex | bis_new/build_bis_extension.py, build_bis_reporters.py |
| Table 5, liquid assets and customer loans | generated/table_balance_composition.tex | body_claims.py |
| Online appendix: milestone timing; the episode in three sanctions datasets | generated/supervisory_timing_table.tex; crosswalk/outputs/table_iran_endpoint_crosswalk.tex | audit_paper.py; crosswalk/build_crosswalk.py |

## Data

| Source | In this package | Access |
|---|---|---|
| Annual accounts filed at Companies House, four banks, 16 statements | banking/bank_financial_panel.csv (checked transcription); banking/report_download_manifest.json (URL and SHA-256 of each filing) | Public. The PDFs are not redistributed; banking/acquire_bank_accounts.py re-acquires them. |
| Trade-finance statements and Melli's undrawn commitments | banking/development_evidence_register.csv, banking/melli_trade_finance_commitments.csv | Same filings; page, hash and check date per row. |
| Legal instruments, supervisory disclosures, Bundesbank TARGET2 roster | legal_new/primary_source_legal_and_access_ledger.csv | Public; source locator per row. |
| BIS Locational Banking Statistics, Iran, 2015-2018 | bis_new/raw (frozen extracts), bis_new/source_manifest.json | Public, under the BIS terms of use. |
| Global Sanctions Data Base (R5, FS), International Sanctions Termination data, Allen-Webb indicators | crosswalk/outputs (derived counts and public extracts, hash-checked) | GSDB case-level data come from the provider under its conditions and are not redistributed; crosswalk/README.md rebuilds the outputs from the original files. |

CLAIM_CHECKS.md lists each substantive claim with its evidence and the limit on inference, including the
page-by-page check of the trade-finance evidence against the filings. MANIFEST_SHA256.txt fingerprints
every file.

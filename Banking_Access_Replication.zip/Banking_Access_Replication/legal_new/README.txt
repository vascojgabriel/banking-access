PRIMARY SOURCES FOR LEGAL, REGULATORY AND BANK-ACCESS MILESTONES

The CSV and JSON contain the same 44 date or source records. Each row records
what the source supports, the relevant entity and jurisdiction, date precision,
and a document locator. Dates use ISO 8601. PDF pages are one-based physical
pages; printed pages record labels visible on the document when available.
An empty date bound or page field means it is unreported, inapplicable or not
verified. Scope is historical and limited to the stated instruments or services.

SOURCES AND TIMING

The regulator and infrastructure rows distinguish original decisions and
circulars from bank statements. The UK PRA/FCA milestones use issuer sources.
The actual regulator letters were not recovered. An exact day in a company
report gives the precision of the disclosed date, not independent validation or
a measure of time attributable to a regulator.

Persia International Bank’s entire 28-page Pillar 3 disclosure as at 31 March
2021 was read. Physical and printed p. 5, §1, reports 7 November 2016 as the
PRA permission to resume normal business. The 296-day comparison uses the
independently corroborated EU annex date, 16 January 2016. The issuer groups
several sanctions jurisdictions in its adjacent historical summary; that summary
is not the legal basis for the date comparison. Its 2016 accounts describe euro
clearing from June, and its following accounts describe continued constraints
on ordinary operations. The PDF validated under SHA-256
fd8ac38aa2bcd16de18101b4ab35866457f92f64389b738ad93b8c83c8bb38e7. HTTPS is
indexed by the browser. The identical publisher host served the complete file
over HTTP when HTTPS access failed in this execution environment.

The Deutsche Bundesbank’s 10 July 2018 direct-participant roster independently
identifies Bank Sepah International PLC (p. 1), Melli Bank Plc (p. 4) and Persia
International Bank PLC (p. 5). The six-page roster lists Bank Saderat Iran and
its Hamburg branch but not London Bank Saderat PLC under its own name. Roster
membership is a point-in-time observation. It does not date first membership,
show a transaction, or resolve indirect access or participation through another
national central bank.

The Hong Kong Monetary Authority circular of 25 June 2008 describes the
section 52(1)(A) restrictions, their depositor-protection purpose and exceptions
for prior approval and capped withdrawals. The removal circular is effective
immediately on 24 June 2016. Service offering in September 2017 comes from
Melli’s accounts, so the elapsed interval is 434–463 days. The bank already held
a local licence. Neither endpoint gives the day of its first customer payment.
The issuer’s reported Dubai constraint is distinct from the DFSA’s 2010 public
notice that the EU freeze covered Persia’s Dubai branch.

The Australian documents distinguish 17 January 2016 activity suspension,
18 January autonomous list change, and 10 February repeal of a separately
specified-entity list. The statutory comparison concerns a new AUD correspondent
relationship with the named parent Bank Melli Iran by a non-US-owned Australian
bank, with no US clearing, special purpose, another listed party or individual
permit. It describes a legal eligibility boundary under assessed instruments.
The package contains no observation that an Australian route actually reopened.

For Bank Saderat PLC, 22 October 2016 is the explicit EU expiry boundary. The
24 October OFSI notice confirms the expiry, and the January 2017 deletion was
for legal certainty. Interpreting 23 October as the first full day after expiry
changes the interval to the disclosed 13 September 2018 permission from 691 to
690 days. The 2016 UK implementing regulations apply to the EU annexes as
amended; their 18 January commencement does not shift the 16 January EU
entity delistings or verify Melli’s reported same-day PRA communication.

The OFAC and SWIFT records further distinguish independently verified national
and infrastructure layers. OFAC's historical guidance expressly retains UK
Bank Saderat PLC on the SDN List at Implementation Day. The May 2018 US
withdrawal announcement, October designation of Bank Mellat, and November
named designations of the UK Melli, Persia and Sepah subsidiaries are distinct
events. SWIFT's January 2016 notice required completion of its normal connection
process. Its November 2018 suspension account reports network actions without
naming the affected banks. The Melli-specific use interruption remains attributed
to its issuer.

DOCUMENT VERIFICATION

The SHA-256 field fingerprints retrieved documents. Some authority texts were
read through the official web editions and have no local hash. The raw filename
field names the retrieved copy for local verification; follow the source URLs
for the public documents. It does not imply that outside publications are
redistributed. All elapsed dates are calendar-day differences. Exact endpoint
spans, including the named PRA intervals and Hong Kong bounds, were checked
from the date strings.

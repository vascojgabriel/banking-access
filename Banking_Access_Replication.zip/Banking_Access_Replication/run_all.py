#!/usr/bin/env python3
"""Rebuild every number, table and the figure from the transcribed accounts, legal records and BIS extracts."""
import csv
import json
from datetime import date
from pathlib import Path
from shutil import copyfile
import subprocess
import sys

import matplotlib
matplotlib.use('Agg')
import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import pandas as pd

ROOT = Path(__file__).resolve().parent
GENERATED = ROOT / 'generated'
BANK_NAMES = {'melli': 'Melli', 'persia': 'Persia', 'saderat': 'Saderat', 'sepah': 'Sepah'}
IMPLEMENTATION = date(2016, 1, 16)
ANNOUNCEMENT = date(2018, 5, 8)


def run(relative_script, *options):
    subprocess.run([sys.executable, '-I', str(ROOT / relative_script), *map(str, options)],
                   cwd=ROOT, check=True)


def plot_loans():
    panel = pd.read_csv(ROOT / 'banking/bank_year_panel.csv', parse_dates=['fiscal_end'])
    fig, ax = plt.subplots(figsize=(8, 4.1))
    for (bank, group), color, marker in zip(panel.groupby('bank', sort=True),
                                          ['#315882', '#963c31', '#537749', '#74548b'],
                                          ['o', 's', 'D', '^'], strict=True):
        group = group.sort_values('fiscal_end')
        level = group.loans_advances_customers
        ax.plot(group.fiscal_end, 100 * level / level.iloc[0], label=BANK_NAMES[bank],
                color=color, marker=marker, linewidth=1.7, markersize=4.5)
    for dt, label in [(IMPLEMENTATION, 'Implementation\n16 Jan 2016'),
                      (ANNOUNCEMENT, 'US withdrawal announced\n8 May 2018')]:
        ax.axvline(dt, color='#666666', linestyle=(0, (4, 3)), linewidth=0.9, zorder=0)
        ax.annotate(label, (mdates.date2num(dt), 1), xycoords=('data', 'axes fraction'),
                    xytext=(0, -6), textcoords='offset points', ha='center', va='top', fontsize=8,
                    bbox={'facecolor': 'white', 'edgecolor': 'none', 'pad': 1})
    ax.set_ylim(25, 120)
    ax.set_ylabel('Customer loan balance (own 2015 = 100)')
    ax.set_xlabel('Fiscal period end')
    ax.set_xlim(date(2015, 1, 1), date(2019, 2, 1))
    ax.set_xticks([date(y, 1, 1) for y in range(2015, 2020)])
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y'))
    ax.yaxis.grid(alpha=0.25)
    ax.spines[['right', 'top']].set_visible(False)
    ax.legend(ncol=4, frameon=False, loc='upper center', bbox_to_anchor=(.5, -.17))
    fig.tight_layout()
    fig.savefig(GENERATED / 'loan_paths.pdf', metadata={'CreationDate': None, 'ModDate': None})
    plt.close(fig)


def validate():
    legal = ROOT / 'legal_new/primary_source_legal_and_access_ledger.csv'
    with legal.open(newline='') as stream:
        legal_rows = list(csv.DictReader(stream))
    for row in legal_rows:
        if row['comparison_anchor_date']:
            anchor = date.fromisoformat(row['comparison_anchor_date'])
            for bound in ('lower', 'upper'):
                calc = (date.fromisoformat(row[f'event_date_{bound}']) - anchor).days
                assert calc == int(row[f'days_from_anchor_{bound}'])
    delays = [int(r['days_from_anchor_lower']) for r in legal_rows if r['days_from_anchor_lower']]
    assert all(days in delays for days in (2, 97, 111, 296, 691))
    absences = pd.read_csv(ROOT / 'banking/bank_financial_panel.csv')
    endpoints = pd.read_csv(ROOT / 'bank_endpoints/outputs/bank_pre_withdrawal_summary.csv')
    bis = pd.read_csv(ROOT / 'bis_new/outputs/bis_annual_paired_positions.csv')
    accounts = absences['value_original']
    assert len(absences) == 128 and accounts.notna().sum() == 100
    assert len(pd.read_csv(ROOT / 'banking/operational_events_all.csv')) == 37
    assert endpoints['loan_stock_last_pre_pct_of_2015'].round(1).tolist() == [57.1, 31.0, 84.1, 38.9]
    flows = bis[bis.measure.str.startswith('sum')].set_index(['series', 'year']).value
    assert round(flows['claims_total', 2016], 3) == -814.357
    assert round(flows['liabilities_total', 2016], 3) == 2998.032
    assert round(flows['liabilities_total', 2016] + flows['liabilities_total', 2017], 3) == 818.661
    rep = pd.read_csv(ROOT / 'bis_new/outputs/bis_liabilities_by_reporter.csv').set_index(['reporter', 'year'])
    assert round(rep.at[('5A', 2016), 'annual'], 3) == 2998.032
    assert round(rep.at[('DE', 2016), 'annual'], 3) == 2489.465
    assert round(rep.at[('GB', 2016), 'annual'], 3) == 10.356
    assert round(rep.at[('residual', 2016), 'q1'], 1) == 1910.1
    report = {'financial_report_count': 16, 'financial_slots': len(absences),
              'financial_values': int(accounts.notna().sum()), 'v7_operational_rows': 37,
              'legal_new_rows': len(legal_rows), 'checks': 'passed'}
    (GENERATED / 'reproduction_checks.json').write_text(json.dumps(report, indent=2) + '\n')


def main():
    GENERATED.mkdir(exist_ok=True)
    run('banking/build_bank_panel.py')
    run('banking/build_operational_extension.py')
    detail_inputs = ROOT / 'bank_endpoints/inputs'
    for filename in ('bank_financial_panel.csv', 'report_download_manifest.json'):
        copyfile(ROOT / 'banking' / filename, detail_inputs / filename)
    run('bank_endpoints/build_bank_endpoints.py')
    run('bis_new/build_bis_extension.py')
    run('bis_new/build_bis_reporters.py')
    run('crosswalk/build_crosswalk.py', '--verify-offline')
    plot_loans()
    validate()
    run('audit_paper.py')
    run('body_claims.py')
    run('verify_numbers.py')
    print('All outputs rebuilt and checked; see generated/.')


if __name__ == '__main__':
    main()

#!/usr/bin/env python3
"""Reproduce timing and balance sheet denominator checks for the four-bank panel."""
import argparse
import json
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parent
US_WITHDRAWAL = pd.Timestamp('2018-05-08')
NAME = {'melli':'Melli','persia':'Persia','saderat':'Saderat','sepah':'Sepah'}


def make_panel(folder):
    transcribed = pd.read_csv(folder/'bank_income_assets_transcription.csv')
    check = pd.read_csv(folder/'bank_income_assets_checks.csv')
    archive = pd.read_csv(folder/'bank_financial_panel.csv',dtype={'company_number':str},parse_dates=['fiscal_end'])
    manifest = pd.DataFrame(json.loads((folder/'report_download_manifest.json').read_text()))
    keys = ['bank','fiscal_year']
    base_fields = ['administrative_expenses','loans_advances_customers','profit_after_tax']
    observed = archive.loc[archive.measure.isin(base_fields)]
    base = observed.pivot(index=keys,columns='measure',values='value_original').reset_index()
    print('bank endpoint counts after reshape:', base[base_fields].count().to_dict())
    assert len(base) == 16 and base[base_fields].count().eq(16).all()
    attrs = observed.loc[observed.measure.eq('administrative_expenses'),
                         keys+['fiscal_end','unit_multiplier','source_url','source_sha256','pdf_page','printed_page','source_filename']]
    assert set(attrs.source_sha256) == set(manifest.sha256) and len(attrs)==16
    attrs = attrs.rename(columns={'pdf_page':'income_pdf_page','printed_page':'income_printed_page'})
    balance_src = archive.loc[archive.measure.eq('loans_advances_banks'),keys+['pdf_page','printed_page']].rename(columns={'pdf_page':'assets_pdf_page','printed_page':'assets_printed_page'})
    out = base.merge(attrs,on=keys,validate='one_to_one').merge(balance_src,on=keys,validate='one_to_one')
    out = out.merge(transcribed,on=keys,validate='one_to_one').merge(check,on=keys,validate='one_to_one')
    assert len(out)==16 and set(out.bank)==set(NAME)
    assert (out.income_reported_base+out.income_additional_subtotal).eq(out.total_operating_income_original).all()
    assert (out.net_interest_income_original+out.net_fee_and_other_components_original).eq(out.total_operating_income_original).all()
    melli = out.bank.eq('melli')
    assert (out.loc[melli,'assets_noncurrent_original']+out.loc[melli,'assets_current_original']).eq(out.loc[melli,'total_assets_original']).all()
    assert (out.loc[melli,'total_operating_income_original']-out.loc[melli,'administrative_expenses']).eq(out.loc[melli,'operating_profit_original']).all()
    ordinary = out.loc[~melli]
    expected_pretax = ordinary.total_operating_income_original-ordinary.administrative_expenses-ordinary.depreciation_original+ordinary.loan_impairment_signed_original+ordinary.other_impairment_signed_original
    assert expected_pretax.eq(ordinary.pretax_profit_original).all()
    for src, result in [('total_operating_income_original','operating_income_eur_million'),('total_assets_original','total_assets_eur_million'),('loans_advances_customers','customer_loans_eur_million'),('profit_after_tax','profit_after_tax_eur_million'),('administrative_expenses','administrative_expenses_eur_million')]:
        out[result] = out[src]*out.unit_multiplier/1e6
    out['customer_loans_share_total_assets_pct'] = 100*out.loans_advances_customers/out.total_assets_original
    out['administrative_expenses_share_operating_income_pct'] = 100*out.administrative_expenses/out.total_operating_income_original
    return out


def endpoint_stats(panel):
    rows = []
    for bank, q in panel.groupby('bank',sort=False):
        q = q.sort_values('fiscal_end')
        start = q.loc[q.fiscal_year.eq(2015)].iloc[0]
        end = q.loc[q.fiscal_end.lt(US_WITHDRAWAL)].iloc[-1]
        annual_2017 = q.loc[q.fiscal_year.eq(2017)].iloc[0]
        final = q.iloc[-1]
        rows.append({'bank':bank,'last_fiscal_endpoint_before_us_withdrawal':end.fiscal_end.date().isoformat(),
                     'loan_stock_2017_pct_of_2015':100*annual_2017.customer_loans_eur_million/start.customer_loans_eur_million,
                     'loan_stock_last_pre_pct_of_2015':100*end.customer_loans_eur_million/start.customer_loans_eur_million,
                     'loan_stock_share_2015':start.customer_loans_share_total_assets_pct,
                     'loan_stock_share_last_pre':end.customer_loans_share_total_assets_pct,
                     'loan_stock_share_2018':final.customer_loans_share_total_assets_pct,
                     'admin_income_2015':start.administrative_expenses_share_operating_income_pct,
                     'admin_income_last_pre':end.administrative_expenses_share_operating_income_pct,
                     'admin_income_2018':final.administrative_expenses_share_operating_income_pct,
                     'profit_2015_eur_million':start.profit_after_tax_eur_million,'profit_last_pre_eur_million':end.profit_after_tax_eur_million})
    return pd.DataFrame(rows)


def latex_table(results):
    lines = [r'\begin{table}[htbp]',r'\centering\small',r'\caption{Bank accounts before the US withdrawal announcement}',r'\label{tab:bank-pre-withdrawal}',r'\setlength{\tabcolsep}{4pt}',r'\begin{tabular}{llrrrrr}',r'\toprule',
             r'& & Loan stock & \multicolumn{2}{c}{Loans / assets (\%)} & \multicolumn{2}{c}{Expenses / income (\%)} \\',r'\cmidrule(lr){4-5}\cmidrule(lr){6-7}',r'Bank & Last pre-8 May endpoint & (\% of 2015) & 2015 & Last pre & 2015 & Last pre \\',r'\midrule']
    for row in results.itertuples(index=False):
        endpoint = pd.Timestamp(row.last_fiscal_endpoint_before_us_withdrawal)
        date = f'{endpoint.day} {endpoint:%b %Y}'
        lines.append(f'{NAME[row.bank]} & {date} & {row.loan_stock_last_pre_pct_of_2015:.1f} & {row.loan_stock_share_2015:.1f} & {row.loan_stock_share_last_pre:.1f} & {row.admin_income_2015:.1f} & {row.admin_income_last_pre:.1f}' + r' \\')
    lines.extend([r'\bottomrule',r'\end{tabular}',r'\par\smallskip',r'\begin{minipage}{0.96\linewidth}\footnotesize',
                  r'Notes. The last observed fiscal endpoint before the 8 May 2018 announcement differs across banks. Loan stocks are reported customer-loan carrying values. Expenses are the separately reported administrative line. Income is reconstructed from statement items or uses the reported operating-income subtotal before impairment charges and administrative expenses. Accounting labels and fiscal windows differ. Comparisons are within banks. Source: sixteen filed accounts.',r'\end{minipage}',r'\end{table}'])
    return '\n'.join(lines)+'\n'



def check_melli_reconciliation(panel, inputs):
    """Check note 7's gross-to-net carrying value against the main panel."""
    columns = ['bank','fiscal_year','customer_loans_eur_million']
    recon = pd.read_csv(inputs/'melli_loan_reconciliation.csv').merge(panel[columns],on=['bank','fiscal_year'],validate='one_to_one')
    assert len(recon) == 2
    assert (recon.gross_customer_loans_eur_thousand-recon.impairment_provision_eur_thousand).eq(
        recon.net_customer_loans_eur_thousand).all()
    assert recon.net_customer_loans_eur_thousand.div(1000).eq(recon.customer_loans_eur_million).all()
    source = panel.loc[panel.bank.eq('melli') & panel.fiscal_year.eq(2018)].iloc[0]
    recon['source_url'] = source.source_url
    recon['source_sha256'] = source.source_sha256
    return recon


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input',type=Path,default=ROOT/'inputs')
    parser.add_argument('--out',type=Path,default=ROOT/'outputs')
    args = parser.parse_args()
    p = make_panel(args.input)
    s = endpoint_stats(p)
    melli = check_melli_reconciliation(p, args.input)
    assert s.loan_stock_2017_pct_of_2015.lt(100).all()
    assert s.loan_stock_last_pre_pct_of_2015.lt(100).all()
    assert s.loan_stock_share_last_pre.lt(s.loan_stock_share_2015).all()
    args.out.mkdir(parents=True,exist_ok=True)
    p.to_csv(args.out/'bank_accounting_denominator_panel.csv',index=False,float_format='%.12g')
    s.to_csv(args.out/'bank_pre_withdrawal_summary.csv',index=False,float_format='%.12g')
    melli.to_csv(args.out/'melli_loan_reconciliation_checked.csv',index=False)
    (args.out/'table_bank_pre_withdrawal.tex').write_text(latex_table(s))
    print(s.round(3).to_string(index=False))


if __name__ == '__main__':
    main()

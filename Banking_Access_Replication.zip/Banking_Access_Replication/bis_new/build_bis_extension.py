#!/usr/bin/env python3
"""Reproduce the paired asset/liability and denominator descriptions for Iran."""
import argparse
from pathlib import Path
import hashlib
import json

import pandas as pd

ROOT = Path(__file__).resolve().parent
YEARS = [2015, 2016, 2017, 2018]
SERIES = [
    ('claims_total', 'claims_detail', 'C', 'A', 'TO1', '5A', 'A'),
    ('claims_banks', 'claims_detail', 'C', 'A', 'TO1', '5A', 'B'),
    ('claims_nonbanks', 'claims_detail', 'C', 'A', 'TO1', '5A', 'N'),
    ('claims_unallocated', 'claims_detail', 'C', 'A', 'TO1', '5A', 'U'),
    ('claims_loan_deposits', 'claims_detail', 'C', 'G', 'TO1', '5A', 'A'),
    ('claims_eur', 'currency', 'C', 'A', 'EUR', '5A', 'A'),
    ('claims_usd', 'currency', 'C', 'A', 'USD', '5A', 'A'),
    ('claims_gbp', 'currency', 'C', 'A', 'GBP', '5A', 'A'),
    ('liabilities_total', 'liabilities_detail', 'L', 'A', 'TO1', '5A', 'A'),
    ('liabilities_banks', 'liabilities_detail', 'L', 'A', 'TO1', '5A', 'B'),
    ('liabilities_nonbanks', 'liabilities_detail', 'L', 'A', 'TO1', '5A', 'N'),
    ('liabilities_unallocated', 'liabilities_detail', 'L', 'A', 'TO1', '5A', 'U'),
    ('liabilities_loan_deposits', 'liabilities_detail', 'L', 'G', 'TO1', '5A', 'A'),
    ('liabilities_eur', 'liabilities_currency', 'L', 'A', 'EUR', '5A', 'A'),
    ('liabilities_usd', 'liabilities_currency', 'L', 'A', 'USD', '5A', 'A'),
    ('liabilities_gbp', 'liabilities_currency', 'L', 'A', 'GBP', '5A', 'A'),
    ('liabilities_germany', 'liabilities_reporters', 'L', 'A', 'TO1', 'DE', 'A'),
    ('liabilities_uk', 'liabilities_reporters', 'L', 'A', 'TO1', 'GB', 'A'),
]
DISPLAY = {
    'claims_total': 'Total claims', 'claims_banks': 'On banks', 'claims_nonbanks': 'On non-banks',
    'liabilities_total': 'Total liabilities', 'liabilities_banks': 'To banks',
    'liabilities_nonbanks': 'To non-banks', 'liabilities_loan_deposits': 'Loans and deposits instrument',
    'liabilities_eur': 'Euro-denominated liabilities', 'liabilities_usd': 'US-dollar-denominated liabilities',
}


def source_data(raw):
    manifest = json.loads((raw.parent/'source_manifest.json').read_text())
    loaded = {}
    identifiers = ['FREQ','L_MEASURE','L_POSITION','L_INSTR','L_DENOM','L_CURR_TYPE',
                   'L_PARENT_CTY','L_REP_BANK_TYPE','L_REP_CTY','L_CP_SECTOR','L_CP_COUNTRY',
                   'L_POS_TYPE','TIME_PERIOD']
    for entry in manifest:
        name = entry['name']
        file = raw/f'bis_{name}.csv'
        assert hashlib.sha256(file.read_bytes()).hexdigest() == entry['sha256'], file
        frame = pd.read_csv(file)
        assert not frame.duplicated(identifiers).any(), file
        for k, v in {'FREQ':'Q', 'L_CURR_TYPE':'A','L_PARENT_CTY':'5J','L_REP_BANK_TYPE':'A',
                     'L_CP_COUNTRY':'IR','L_POS_TYPE':'N','UNIT_MEASURE':'USD','UNIT_MULT':6}.items():
            assert set(frame[k].dropna()) == {v}, (file, k, frame[k].unique())
        frame['quarter'] = pd.PeriodIndex(frame.TIME_PERIOD, freq='Q')
        loaded[name] = frame
    return loaded


def extract(frames):
    series = []
    for name, file, position, instr, denom, reporter, sector in SERIES:
        frame = frames[file]
        selection = frame.loc[frame.L_POSITION.eq(position) & frame.L_INSTR.eq(instr) &
                              frame.L_DENOM.eq(denom) & frame.L_REP_CTY.eq(reporter) &
                              frame.L_CP_SECTOR.eq(sector), ['quarter','L_MEASURE','OBS_VALUE','OBS_STATUS','OBS_CONF']].copy()
        assert len(selection), name
        selection['series'] = name
        series.append(selection)
    return pd.concat(series,ignore_index=True)


def aggregate(series):
    rows = []
    for name, raw in series.groupby('series',sort=False):
        for year in YEARS:
            for kind in ['F','S']:
                g = raw.loc[raw.quarter.dt.year.eq(year) & raw.L_MEASURE.eq(kind)]
                if kind == 'F':
                    assert len(g) == 4 and g.OBS_VALUE.notna().all(), (name,year,g)
                    rows.append({'series':name,'year':year,'measure':'sum_of_adjusted_quarterly_changes_usd_million',
                                 'value':g.OBS_VALUE.sum(),'numeric_quarters':4})
                else:
                    q4 = g.loc[g.quarter.dt.quarter.eq(4),'OBS_VALUE']
                    assert len(q4) == 1 and q4.notna().all(), (name,year,g)
                    rows.append({'series':name,'year':year,'measure':'q4_stock_usd_million',
                                 'value':q4.iloc[0],'numeric_quarters':1})
    return pd.DataFrame(rows)


def write_table(year):
    cols = [2015, 2016, 2017]
    lines = [r'\begin{table}[htbp]', r'\centering\small', r'\caption{Cross-border bank positions vis-\`a-vis Iran, adjusted changes}',
             r'\label{tab:bis-positions}',r'\begin{tabular}{lrrrr}',r'\toprule',
             r'& 2015 & 2016 & 2017 & 2016--2017 \\', r'\midrule']
    for name, label in DISPLAY.items():
        if name == 'liabilities_total': lines.append(r'\addlinespace')
        values = [year.at[name,y] for y in cols]
        values.append(values[1]+values[2])
        nums = ' & '.join(fr'${v:,.0f}$'.replace(',', '{,}') for v in values)  # no math-mode space after thousands separator
        lines.append(f'{label} & {nums}' + r' \\')
    lines.extend([r'\bottomrule',r'\end{tabular}',r'\par\smallskip',
        r'\begin{minipage}{0.94\linewidth}\footnotesize',
        r'Notes. Amounts in US\$ million. The BIS corrects quarterly changes for exchange rates and breaks in reporting. Annual values sum four quarters. Claims and liabilities are those of reporting banks vis-\`a-vis residents of Iran. The instrument and currency rows describe overlapping margins of total liabilities. The euro and dollar rows identify the denomination of liabilities and are both reported in US dollars. Bank and non-bank subtotals omit unallocated sectors and can display rounding differences. Source: BIS locational banking statistics.', r'\end{minipage}',r'\end{table}'])
    return '\n'.join(lines)+'\n'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out-dir',type=Path,default=ROOT/'outputs')
    args = parser.parse_args()
    raw = extract(source_data(ROOT/'raw'))
    results = aggregate(raw)
    yr = results.loc[results.measure.str.startswith('sum')].pivot(index='series',columns='year',values='value')
    stock = results.loc[results.measure.str.startswith('q4')].pivot(index='series',columns='year',values='value')
    counts = {key: frame.count().to_dict() for key, frame in [('adjusted', yr), ('stocks', stock)]}
    print('BIS populated cells after reshape:', counts)
    assert all(frame.count().eq(len(frame)).all() for frame in (yr, stock))
    checks = {}
    for pos in ['claims','liabilities']:
        components = yr.loc[[f'{pos}_banks',f'{pos}_nonbanks',f'{pos}_unallocated']].sum(axis=0)
        checks[f'{pos}_max_sector_reconciliation_error_usd_million'] = float((components-yr.loc[f'{pos}_total']).abs().max())
        assert checks[f'{pos}_max_sector_reconciliation_error_usd_million'] < 0.04
    checks['published_v7_aggregate_claims_deltas_match_at_3_decimals'] = all(
        round(yr.at['claims_total',y],3) == v for y,v in {2015:-713.268,2016:-814.357,2017:-496.335}.items())
    checks['published_v7_aggregate_claims_stocks_match_at_3_decimals'] = all(
        round(stock.at['claims_total',y],3) == v for y,v in {2015:3090.946,2016:2216.415,2017:1943.540}.items())
    assert checks['published_v7_aggregate_claims_deltas_match_at_3_decimals']
    assert checks['published_v7_aggregate_claims_stocks_match_at_3_decimals']
    checks['liability_instrument_not_a_currency_decomposition'] = True
    checks['outstanding_claims_not_gross_new_credit'] = True
    args.out_dir.mkdir(parents=True,exist_ok=True)
    raw.assign(quarter=raw.quarter.astype(str)).to_csv(args.out_dir/'bis_quarterly_paired_positions.csv',index=False,float_format='%.12g')
    results.to_csv(args.out_dir/'bis_annual_paired_positions.csv',index=False,float_format='%.12g')
    (args.out_dir/'table_bis_paired_positions.tex').write_text(write_table(yr))
    (args.out_dir/'bis_extension_checks.json').write_text(json.dumps(checks,indent=2)+'\n')
    print(yr.loc[list(DISPLAY)].round(3).to_string())
    print(json.dumps(checks,indent=2))


if __name__ == '__main__':
    main()

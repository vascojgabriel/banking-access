"""Reconcile disclosed BIS reporting-country liability changes to the aggregate.

Quarterly differences between the all-reporter total and the sum of disclosed
countries remain in a residual. They cannot be attributed to any particular
country, bank, currency or category of unpublished observation.
"""
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parent
RAW = ROOT / 'raw/bis_liabilities_reporters.csv'
OUT = ROOT / 'outputs'
KEY = dict(FREQ='Q', L_POSITION='L', L_INSTR='A', L_DENOM='TO1', L_CURR_TYPE='A',
           L_PARENT_CTY='5J', L_REP_BANK_TYPE='A', L_CP_SECTOR='A', L_CP_COUNTRY='IR',
           L_POS_TYPE='N', UNIT_MEASURE='USD', UNIT_MULT=6)
YEARS = (2016, 2017)
FOCUS = YEARS[0]
THRESHOLD = 150.0
NAMES = {'AT': 'Austria', 'AU': 'Australia', 'BE': 'Belgium', 'CA': 'Canada', 'CH': 'Switzerland',
         'CL': 'Chile', 'DE': 'Germany', 'DK': 'Denmark', 'ES': 'Spain', 'FI': 'Finland',
         'FR': 'France', 'GB': 'United Kingdom', 'GG': 'Guernsey', 'GR': 'Greece',
         'HK': 'Hong Kong SAR', 'IE': 'Ireland', 'IM': 'Isle of Man', 'IT': 'Italy',
         'JE': 'Jersey', 'JP': 'Japan', 'KR': 'Korea', 'LU': 'Luxembourg', 'MO': 'Macao SAR',
         'NL': 'Netherlands', 'PH': 'Philippines', 'SE': 'Sweden', 'TW': 'Chinese Taipei',
         'US': 'United States', 'ZA': 'South Africa'}


def main():
    OUT.mkdir(exist_ok=True)
    raw = pd.read_csv(RAW)
    for column, expected in KEY.items():
        assert raw[column].eq(expected).all(), column
    quarters = {year: [f'{year}-Q{q}' for q in range(1, 5)] for year in YEARS}
    periods = sum(quarters.values(), [])
    data = raw.loc[raw.L_MEASURE.eq('F') & raw.TIME_PERIOD.isin(periods)]
    assert not data.duplicated(['L_REP_CTY', 'TIME_PERIOD']).any()
    assert data.loc[data.OBS_VALUE.isna(), 'OBS_STATUS'].eq('Q').all()
    wide = data.pivot(index='L_REP_CTY', columns='TIME_PERIOD', values='OBS_VALUE').reindex(columns=periods)
    observed = data.groupby('TIME_PERIOD').OBS_VALUE.count().reindex(periods)
    assert wide.count().equals(observed)
    total = wide.loc['5A']
    assert total.notna().all()
    bank_data = pd.read_csv(OUT/'bis_quarterly_paired_positions.csv')
    independent_total = bank_data.loc[bank_data.series.eq('liabilities_total') & bank_data.L_MEASURE.eq('F')]
    independently_published = independent_total.set_index(independent_total.quarter.str.replace('Q', '-Q')).OBS_VALUE
    assert (total - independently_published.loc[periods]).abs().lt(1e-6).all()

    reporters = wide.drop(index='5A')
    assert set(reporters.index) <= set(NAMES)
    print('BIS reporter reshape, disclosed country cells:', reporters.count().to_dict())
    print('BIS reporter reshape, missing country cells:', reporters.isna().sum().to_dict())
    disclosed = reporters.sum(min_count=1)
    assert disclosed.notna().all()
    residual = total - disclosed
    focus = reporters[quarters[FOCUS]].sum(axis=1, min_count=4)
    shown = focus[reporters.notna().all(axis=1) & (focus.abs().ge(THRESHOLD) | (focus.index == 'GB'))]
    shown = shown.sort_values(ascending=False).index
    assert {'DE', 'GB'} <= set(shown)
    other = reporters.drop(index=shown).sum(min_count=1)
    assert other.notna().all()
    assert (reporters.loc[shown].sum() + other + residual - total).abs().lt(1e-6).all()

    rows = []
    sources = [(c, NAMES[c], values) for c, values in reporters.iterrows()]
    sources += [('residual', 'Residual', residual), ('5A', 'All reporting countries', total)]
    for code, name, values in sources:
        for year, cols in quarters.items():
            span = values[cols]
            rows.append(dict(reporter=code, name=name, year=year, quarters_disclosed=span.count(),
                             q1=span.iloc[0], annual=span.sum(min_count=4),
                             shown_in_table=code in shown or code in ('residual', '5A')))
    records = pd.DataFrame(rows)
    assert records.annual.notna().eq(records.quarters_disclosed.eq(4)).all()
    records.to_csv(OUT/'bis_liabilities_by_reporter.csv', index=False, float_format='%.3f')

    def table_row(name, values):
        return dict(name=name, **{'2016Q1': values.iloc[0]},
                    **{str(y): values[qu].sum(min_count=4) for y, qu in quarters.items()})

    table = pd.DataFrame(
        [table_row(NAMES[c], reporters.loc[c]) for c in shown]
        + [table_row('Other disclosed country observations', other),
           table_row('Residual', residual), table_row('All reporting countries', total)]
    )
    numeric = [c for c in table if c != 'name']
    assert (table.iloc[:-1][numeric].sum() - table.iloc[-1][numeric].astype(float)).abs().lt(1e-6).all()
    table.to_csv(OUT/'bis_liabilities_reporter_table.csv', index=False, float_format='%.3f')

    def cell(value):
        return f'{value:,.0f}'.replace('-', r'\ensuremath{-}')

    lines = [r'\begin{table}[!htbp]', r'\centering\small',
             r'\caption{Adjusted change in liabilities to Iranian residents by reporting country}',
             r'\label{tab:bis-reporters}', r'\begin{tabular}{@{}lrrr@{}}', r'\toprule',
             rf'Reporting country & {FOCUS}Q1 & {FOCUS} & {FOCUS+1} \\', r'\midrule']
    for row in table.itertuples(index=False, name=None):
        if row[0] == 'All reporting countries':
            lines.append(r'\midrule')
        lines.append(' & '.join([row[0], *(cell(x) for x in row[1:])]) + r' \\')
    limit = r'US\$' + f'{THRESHOLD:.0f} million'
    lines.extend([r'\bottomrule', r'\end{tabular}', r'\par\smallskip\footnotesize\raggedright',
                  (f'In millions of US dollars. Changes are adjusted for exchange rates and breaks. '
                   f'The bilateral extract has {len(reporters)} reporting countries. The table displays the UK '
                   f'and countries with an absolute {FOCUS} change of at least {limit} '
                   f'and complete observations for both years. Other disclosed observations are summed by quarter. '
                   f'The residual is the all-reporter total less the disclosed country values. It includes '
                   f'unpublished observations and any coverage differences. Rounding may affect sums.'),
                  r'\end{table}'])
    (OUT/'table_bis_reporters.tex').write_text('\n'.join(lines)+'\n')


if __name__ == '__main__':
    main()

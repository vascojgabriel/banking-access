BIS cross-border claims and liabilities vis-à-vis Iran

Run Python 3.12 with pandas from any working directory:

    python build_bis_extension.py

The script verifies the five frozen API extracts against source_manifest.json and writes quarterly and annual CSVs, an annual LaTeX table and verification results. No network call is made during reproduction. The manifest preserves the exact SDMX URLs, bounded query keys, response dates and SHA-256 hashes. The provider's data can be revised; a fresh query and a reproduction against the frozen extracts answer different questions.

Dataset: Bank for International Settlements, Locational Banking Statistics, detailed public dataflow BIS:WS_LBS_D_PUB(1.0). Portal and reporting information:
  https://data.bis.org/topics/LBS
  https://data.bis.org/topics/LBS/tables-and-dashboards
  https://www.bis.org/statistics/bankstatsguide_repreqloc.pdf
  https://www.bis.org/pages/statistics/lbs-data-structure-definition.pdf
  https://data.bis.org/help/glossary?item=Loans+and+deposits

The reporting scope is all reporting banking offices (5A), with separately shown Germany and UK residence series. Iranian residents (IR) are the counterparty. Q denotes quarterly, N the cross-border/non-local position flag, C claims and L liabilities. A covers all instruments or, on the sector dimension, all counterparties; B means bank counterparties, N non-bank counterparties, and U unallocated by sector. G is the published loans and deposits instrument category. It includes deposits, loans to the reporting banks, and related items under the BIS definitions. Its liability-side change is not a measure of gross new deposits. Reporting is unconsolidated by location; related-office/intragroup positions can be included. The source does not reveal account holders, beneficiary identities, the legal status or usability of the funds, or settlement activity. The central-bank category lacks usable released observations in the selected series, so the bank-counterparty result is not attributed to the central bank.

S reports amounts outstanding and F reports BIS-calculated quarterly changes after exchange-rate and break adjustment. Four observed changes are added for each annual adjusted change; the fourth-quarter endpoint is the year-end stock. These series need not coincide. All amounts, including rows for EUR or GBP denomination, are US dollars millions (UNIT_MEASURE USD, UNIT_MULT 6). TO1 is all denominations. Currency, counterparty-sector, instrument and reporter rows are distinct cuts; their values must not be added across cuts. EUR identifies the denomination of liabilities, not the clearing channel or residence of the reporter.

The revised extracts exactly reproduce stocks and adjusted changes on the claims side used in the prior paper's table. Bank, non-bank and unallocated sectors reconcile to published claims and liabilities totals within USD0.001 million. The files are historical releases, not a real-time vintage or a causal evaluation. They describe only the position side of financial access and are separate from the four-bank accounting sample.


Reporting-country breakdown (2016 and 2017).
Run the paired-series script before build_bis_reporters.py. The latter verifies the
all-reporter row against the separately queried aggregate in each quarter and checks
the sums of displayed countries, other disclosed values and the residual. The country
in each series is the reporting office's residence. Observations missing or suppressed
at source are never written as zero. The residual also retains aggregate coverage
differences. Country net changes can include offsetting positions at individual banks.

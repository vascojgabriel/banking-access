"""Recompute the paper's headline numbers independently of the generators and compare them with the macros.

The BIS figures are recomputed from the frozen raw extracts, the bank figures from the year panel and the
trade-finance commitments from their transcription; the balance-composition table is rebuilt row by row.
Usage: python verify_numbers.py [package root]. Exits with an error on any mismatch with a macro in use.
"""
import re, sys
from pathlib import Path
import pandas as pd
root = sys.argv[1] if len(sys.argv) > 1 else str(Path(__file__).resolve().parent)
raw = f'{root}/bis_new/raw'
fs = ['bis_claims_detail.csv', 'bis_liabilities_detail.csv', 'bis_currency.csv',
      'bis_liabilities_currency.csv', 'bis_liabilities_reporters.csv']
d = pd.concat([pd.read_csv(f'{raw}/{f}', dtype={'TIME_PERIOD': str}) for f in fs]).drop_duplicates(
    subset=['L_MEASURE', 'L_POSITION', 'L_INSTR', 'L_DENOM', 'L_CP_SECTOR', 'L_REP_CTY', 'TIME_PERIOD'])
d['year'] = d.TIME_PERIOD.str[:4].astype(int)
def ser(pos, sector='A', instr='A', denom='TO1', rep='5A', meas='F'):
    s = d[(d.L_POSITION == pos) & (d.L_CP_SECTOR == sector) & (d.L_INSTR == instr) & (d.L_DENOM == denom)
          & (d.L_REP_CTY == rep) & (d.L_MEASURE == meas)]
    return s.set_index('TIME_PERIOD').OBS_VALUE.sort_index()
def yr(s, y): v = s[[f'{y}-Q{q}' for q in range(1, 5)]]; assert v.notna().all(); return v.sum()
def usd(x): x = abs(x); return f'${x/1000:.2f} billion' if x >= 500 else f'${x:.0f} million'
C, L = ser('C'), ser('L')
LB, LN = ser('L', sector='B'), ser('L', sector='N')
LLD, LEUR = ser('L', instr='G'), ser('L', denom='EUR')
CS = ser('C', meas='S')
rep = d[(d.L_POSITION == 'L') & (d.L_MEASURE == 'F') & (d.L_CP_SECTOR == 'A') & (d.L_INSTR == 'A') & (d.L_DENOM == 'TO1')]
pv = rep.pivot(index='L_REP_CTY', columns='TIME_PERIOD', values='OBS_VALUE')
q16 = [f'2016-Q{q}' for q in range(1, 5)]
resid = pv.loc['5A'] - pv.drop(index='5A').sum(min_count=1).fillna(0)
loo = [yr(L, 2016) - L[c] for c in q16]
exp = {'ClaimsFall': usd(yr(C, 2016)), 'LiabilityRise': usd(yr(L, 2016)), 'LiabBanks': usd(yr(LB, 2016)),
       'LiabNonBanksFall': usd(yr(LN, 2016)), 'LiabLoansDeposits': usd(yr(LLD, 2016)), 'LiabEUR': usd(yr(LEUR, 2016)),
       'LiabFallNext': usd(yr(L, 2017)), 'LiabCum': usd(yr(L, 2016) + yr(L, 2017)),
       'ClaimsCumFall': usd(yr(C, 2016) + yr(C, 2017)), 'ClaimsFallNext': usd(yr(C, 2017)),
       'ClaimsStockBase': usd(CS['2015-Q4']), 'ClaimsStockRelief': usd(CS['2016-Q4']), 'ClaimsStockNext': usd(CS['2017-Q4']),
       'LiabQOne': usd(L['2016-Q1']), 'LiabilityLow': usd(min(loo)), 'LiabilityHigh': usd(max(loo)),
       'DELiab': usd(pv.loc['DE', q16].sum()), 'DELiabQOne': usd(pv.at['DE', '2016-Q1']),
       'DELiabNext': usd(pv.loc['DE', [f'2017-Q{q}' for q in range(1, 5)]].sum()), 'GBLiab': usd(pv.loc['GB', q16].sum()),
       'JPLiab': usd(pv.loc['JP', q16].sum()), 'KRLiabFall': usd(pv.loc['KR', q16].sum()), 'CHLiabFall': usd(pv.loc['CH', q16].sum()),
       'ResidQOne': usd(resid['2016-Q1']), 'ResidYearFall': usd(resid[q16].sum())}
exp.update({'BISSumRelief': usd(yr(C, 2016) + yr(L, 2016)), 'BISNetReliefFall': usd(yr(C, 2016) - yr(L, 2016)),
            'BISSumTwoYearFall': usd(yr(C, 2016) + yr(L, 2016) + yr(C, 2017) + yr(L, 2017)),
            'BISNetTwoYearFall': usd(yr(C, 2016) - yr(L, 2016) + yr(C, 2017) - yr(L, 2017))})
assert yr(C, 2016) < 0 < yr(L, 2016) and all(v > 0 for v in loo) and pv.loc['KR', q16].sum() < 0
p = pd.read_csv(f'{root}/banking/bank_year_panel.csv', parse_dates=['fiscal_end'])
legal = pd.read_csv(f'{root}/legal_new/primary_source_legal_and_access_ledger.csv').set_index('record_id')
announcement = legal.loc['us_withdrawal_announcement']
assert announcement.event_date_lower == announcement.event_date_upper
cut = pd.Timestamp(announcement.event_date_lower)
relief = pd.Timestamp(legal.at['melli_eu_delisting', 'event_date_lower'])
loan_ratios = []
assert p.loans_advances_customers.notna().all() and not p.duplicated(['bank', 'fiscal_year']).any()
assert sorted(p.groupby('bank').size()) == [4, 4, 4, 4]
for b, lab in [('melli', 'Melli'), ('persia', 'Persia'), ('saderat', 'Saderat'), ('sepah', 'Sepah')]:
    g = p[p.bank == b].sort_values('fiscal_end'); base = g[g.fiscal_year == 2015].iloc[0]; last = g[g.fiscal_end < cut].iloc[-1]
    ratio = 100 * last.loans_advances_customers / base.loans_advances_customers
    loan_ratios.append(ratio)
    exp[f'Loan{lab}Pre'] = f'{ratio:.0f}'
    m = lambda x: f'EUR{x:.0f} million' if x >= 10 else f'EUR{x:.1f} million'
    exp[f'Banks{lab}Base'], exp[f'Banks{lab}Pre'] = m(base.loans_advances_banks), m(last.loans_advances_banks)
    exp[f'Cash{lab}Base'], exp[f'Cash{lab}Pre'] = m(base.cash_reported), m(last.cash_reported)
exp.update({'LoanRange': f'{min(loan_ratios):.0f}--{max(loan_ratios):.0f}',
            'BankCount': {4: 'four'}[p.bank.nunique()], 'FilingCount': str(len(p)),
            'BaseYear': str(p.fiscal_year.min()), 'ReliefYear': str(relief.year),
            'WithdrawalDate': f'{cut.day} {cut:%B %Y}'})
# rev8: Melli's undrawn trade-finance commitments straight from the transcription file, and the loan endpoints
import os
if os.path.exists(f'{root}/banking/melli_trade_finance_commitments.csv'):
    tf = pd.read_csv(f'{root}/banking/melli_trade_finance_commitments.csv')
    cell = lambda fy, end: tf[(tf.filing_year == fy) & (tf.fiscal_end == end)].undrawn_commitments_eur.item()
    assert cell(2017, '2016-12-31') == 0 and cell(2017, '2017-12-31') == cell(2018, '2017-12-31')
    exp['MelliCommitmentStart'] = 'nil'
    exp['MelliCommitmentPre'] = f'EUR{cell(2017, "2017-12-31") / 1e6:.0f} million'
    exp['MelliCommitmentPost'] = f'EUR{cell(2018, "2018-12-31") / 1e6:.0f} million'
    mel = p[p.bank == 'melli'].set_index('fiscal_end').loans_advances_customers
    exp['MelliLoansEarlier'] = f'EUR{mel[pd.Timestamp("2016-12-31")]:.3f} million'
    exp['MelliNetA'] = f'EUR{mel[pd.Timestamp("2017-12-31")]:.3f} million'
mac = {}
for f in ('paper_claims.tex', 'body_claims.tex'):
    for line in open(f'{root}/generated/{f}'):
        k, v = re.fullmatch(r'\\newcommand\{\\([A-Za-z]+)\}\{(.*)\}\n?', line).groups(); mac[k] = v.replace('\\$', '$')
bad = {k: (v, mac.get(k)) for k, v in exp.items() if mac.get(k) != v}
unused = sorted(k for k, (_, got) in bad.items() if got is None)  # computed here, not used in the paper
wrong = {k: v for k, v in bad.items() if v[1] is not None}
print(f'{len(exp) - len(unused)} macros in use recomputed independently; mismatches: {wrong or "none"}')
assert not wrong, wrong


# Balance-composition table, recomputed from the year panel without the generator's code
import re as _re, sys as _sys
from pathlib import Path as _P
import pandas as _pd
_root = _P(root); _tab = (_root / 'generated' / 'table_balance_composition.tex').read_text()
_yp = _pd.read_csv(_root / 'banking' / 'bank_year_panel.csv', parse_dates=['fiscal_end'])
_mon = {'Jan.': 1, 'Feb.': 2, 'Mar.': 3, 'Apr.': 4, 'May': 5, 'June': 6, 'July': 7, 'Aug.': 8, 'Sept.': 9, 'Oct.': 10, 'Nov.': 11, 'Dec.': 12}
_rows = _re.findall(r'^(Persia|Sepah|Melli|Saderat) & (\S+) (\d{4}) & (.*?) \\\\$', _tab, _re.M)
assert len(_rows) == 6, _rows
_bad = []
for _bank, _m, _y, _vals in _rows:
    _b = _yp[_yp.bank == _bank.lower()].sort_values('fiscal_end')
    _x = _b.iloc[0]; _e = _b[(_b.fiscal_end.dt.year == int(_y)) & (_b.fiscal_end.dt.month == _mon[_m])].iloc[0]
    _d = [_e.cash_reported - _x.cash_reported, _e.loans_advances_banks - _x.loans_advances_banks]
    _d = [_d[0], _d[1], _d[0] + _d[1], _e.loans_advances_customers - _x.loans_advances_customers]
    _got = [float(v.replace(r'\ensuremath{-}', '-')) for v in _vals.split(' & ')]
    if [f'{v:.1f}' for v in _d] != [f'{v:.1f}' for v in _got]: _bad.append((_bank, _m, _y, _d, _got))
print(f'balance-composition table: {len(_rows)} rows recomputed; mismatches: {_bad or "none"}')
assert not _bad, _bad

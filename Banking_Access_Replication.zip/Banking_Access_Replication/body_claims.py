"""Generate the substantive numerical claims used in the manuscript and appendix.

Each macro is computed from a build output, its sign or ordering claim is asserted, and a
ledger row records the file, the cell and the check. Outputs:
  generated/body_claims.tex        LaTeX macros
  generated/body_claim_ledger.csv  provenance and checks
  generated/table_milestones.tex   Table 1 of the manuscript
"""
import csv
import json
import re
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'generated'
LEGAL = 'legal_new/primary_source_legal_and_access_ledger.csv'
US2007 = 'legal_new/us_designations_2007.csv'
OPS = 'banking/operational_events_all.csv'
PANEL = 'banking/bank_year_panel.csv'
FIN = 'banking/bank_financial_panel.csv'
ENDPOINTS = 'bank_endpoints/outputs/bank_pre_withdrawal_summary.csv'
RECON = 'bank_endpoints/outputs/melli_loan_reconciliation_checked.csv'
ANNUAL = 'bis_new/outputs/bis_annual_paired_positions.csv'
QUARTERLY = 'bis_new/outputs/bis_quarterly_paired_positions.csv'
REPORTERS = 'bis_new/outputs/bis_liabilities_by_reporter.csv'
CROSSWALK = 'crosswalk/outputs/iran_endpoint_crosswalk.csv'
TIMING = 'generated/supervisory_timing_counts.csv'
MANIFEST = 'banking/report_download_manifest.json'
COMMITMENTS = 'banking/melli_trade_finance_commitments.csv'
REGISTER = 'banking/development_evidence_register.csv'
WORDS = {0: 'no', 1: 'one', 2: 'two', 3: 'three', 4: 'four', 5: 'five', 6: 'six', 7: 'seven',
         8: 'eight', 9: 'nine', 10: 'ten'}
ABBR = {1: 'Jan.', 2: 'Feb.', 3: 'Mar.', 4: 'Apr.', 5: 'May', 6: 'June', 7: 'July', 8: 'Aug.',
        9: 'Sept.', 10: 'Oct.', 11: 'Nov.', 12: 'Dec.'}
rows = []


def emit(macro, display, source, cell, check):
    assert macro.isalpha() and macro[0].isupper(), macro
    assert macro not in {r['macro'] for r in rows}, macro
    rows.append(dict(macro=macro, display=str(display), file=source, record_or_cell=cell, test=check))


def dmy(ts):
    return f'{ts.day} {ts:%B %Y}'


def dm(ts):
    return f'{ts.day} {ts:%B}'


def my(ts):
    return f'{ts:%B %Y}'


def short(ts):
    return f'{ts.day} {ABBR[ts.month]} {ts.year}'


def usd(x):
    """Absolute value in US$, billions from 500 million; the sign is carried by the prose."""
    x = abs(x)
    return rf'\${x / 1000:.2f} billion' if x >= 500 else rf'\${x:.0f} million'


def eur_m(x):
    return f'EUR{x:.0f} million' if abs(x) >= 10 else f'EUR{x:.1f} million'


def eur_k(x_thousand):
    return f'EUR{x_thousand * 1000:,.0f}'


def main():
    legal = pd.read_csv(ROOT / LEGAL).set_index('record_id')
    lo = lambda r: pd.Timestamp(legal.at[r, 'event_date_lower'])
    hi = lambda r: pd.Timestamp(legal.at[r, 'event_date_upper'])

    def exact(r):
        assert lo(r) == hi(r), r
        return lo(r)

    def month(r):
        a, b = lo(r), hi(r)
        assert (a.year, a.month) == (b.year, b.month) and a.day == 1 and b.is_month_end, r
        return a

    # Legal and supervisory dates
    impl = exact('melli_eu_delisting')
    assert impl == exact('persia_eu_delisting') == pd.Timestamp('2016-01-16')
    emit('ImplementationDay', dmy(impl), LEGAL, 'melli_eu_delisting, persia_eu_delisting', 'equal exact dates')
    emit('UKRulesDay', dm(exact('uk_implementing_si_2016')), LEGAL, 'uk_implementing_si_2016', 'exact date')
    emit('SepahUNDay', dm(exact('sepah_un_delisting')), LEGAL, 'sepah_un_delisting', 'exact date')
    sepah_eu = exact('sepah_eu_delisting')
    emit('SepahEUDay', dm(sepah_eu), LEGAL, 'sepah_eu_delisting', 'exact date, after UN removal')
    assert exact('sepah_un_delisting') < sepah_eu
    emit('SaderatReplaceDay', dmy(exact('saderat_eu_replacement_2016')), LEGAL, 'saderat_eu_replacement_2016', 'exact date')
    sad = exact('saderat_eu_expiry_2016')
    emit('SaderatExpiry', dmy(sad), LEGAL, 'saderat_eu_expiry_2016', 'exact date')
    assert exact('saderat_uk_notice_2016') > sad
    emit('MelliPRADay', dmy(exact('pra_no_objection')), LEGAL, 'pra_no_objection', 'exact date')
    assert exact('pra_no_objection') == exact('uk_implementing_si_2016')  # appendix: same day as UK commencement
    emit('SepahPRADay', dmy(exact('sepah_2016_19')), LEGAL, 'sepah_2016_19', 'exact date')
    emit('SepahFCADay', dmy(exact('sepah_2017_20')), LEGAL, 'sepah_2017_20', 'exact date after PRA letter')
    assert exact('sepah_2017_20') > exact('sepah_2016_19')
    emit('SaderatConfirmDay', dmy(exact('saderat_2018_15')), LEGAL, 'saderat_2018_15', 'exact date after withdrawal')
    withdrawal = exact('us_withdrawal_announcement')
    assert exact('saderat_2018_15') > withdrawal
    emit('WithdrawalYear', withdrawal.year, LEGAL, 'us_withdrawal_announcement', 'calendar year')
    emit('SepahClearingMonth', my(month('sepah_2017_21')), LEGAL, 'sepah_2017_21', 'one calendar month')
    a, b = lo('sepah_2018_23'), hi('sepah_2018_23')
    assert (a.month, a.day, b.month, b.day, a.year) == (1, 1, 12, 31, b.year)
    emit('SepahActivityYear', a.year, LEGAL, 'sepah_2018_23', 'one calendar year')
    hk = exact('hkma_melli_removal')
    emit('HKRemovalDay', dmy(hk), LEGAL, 'hkma_melli_removal', 'exact date')
    assert pd.isna(legal.at['hk_chats_access', 'event_date_lower'])
    emit('HKChatsBy', my(hi('hk_chats_access')), LEGAL, 'hk_chats_access upper bound', 'reported by date')
    emit('HKResumeMonth', my(month('hk_service_resumption')), LEGAL, 'hk_service_resumption', 'one calendar month')
    assert legal.at['hk_service_resumption', 'comparison_anchor_date'] == hk.date().isoformat()
    hk_lo = int(legal.at['hk_service_resumption', 'days_from_anchor_lower'])
    hk_hi = int(legal.at['hk_service_resumption', 'days_from_anchor_upper'])
    assert (month('hk_service_resumption') - hk).days == hk_lo and (hi('hk_service_resumption') - hk).days == hk_hi
    emit('HKGapLow', hk_lo, LEGAL, 'hk_service_resumption days_from_anchor_lower', 'recomputed from dates')
    emit('HKGapHigh', hk_hi, LEGAL, 'hk_service_resumption days_from_anchor_upper', 'recomputed from dates')
    emit('MelliSwiftMonth', my(month('melli_2018_02')), LEGAL, 'melli_2018_02', 'one calendar month')
    assert pd.isna(legal.at['melli_2018_03', 'event_date_lower'])
    emit('MelliRestoredBy', my(hi('melli_2018_03')), LEGAL, 'melli_2018_03 upper bound', 'accounts approval date')
    roster = exact('melli_bbk_target2_snapshot')
    emit('RosterDay', dmy(roster), LEGAL, 'melli_bbk_target2_snapshot', 'exact roster date')
    redesig = exact('melli_us_named_designation_2018')
    assert redesig == exact('persia_us_named_designation_2018') == exact('sepah_us_named_designation_2018')
    emit('USRedesignationDay', dmy(redesig), LEGAL, 'three named 2018 OFAC records', 'equal exact dates after withdrawal')
    assert redesig > withdrawal
    persia_perm = exact('persia_pra_2016')
    clear_lo, clear_hi = lo('persia_2016_06'), hi('persia_2016_06')
    assert clear_hi < persia_perm
    emit('PersiaGapLow', (persia_perm - clear_hi).days, LEGAL, 'persia_2016_06 upper to persia_pra_2016', 'days')
    emit('PersiaGapHigh', (persia_perm - clear_lo).days, LEGAL, 'persia_2016_06 lower to persia_pra_2016', 'days')

    # Earlier US designations of the four subsidiaries
    us = pd.read_csv(ROOT / US2007, parse_dates=['designation_date']).set_index('bank')
    assert set(us.index) == {'melli', 'persia', 'saderat', 'sepah'}
    assert us.loc[['melli', 'persia', 'saderat'], 'designation_date'].nunique() == 1
    assert 'alias' in us.at['saderat', 'source_locator']
    assert us.at['sepah', 'designation_date'] < us.at['melli', 'designation_date']
    emit('USDesigSepah', my(us.at['sepah', 'designation_date']), US2007, 'sepah designation_date', 'earliest designation')
    emit('USDesigOthers', my(us.at['melli', 'designation_date']), US2007, 'melli, persia, saderat designation_date', 'common date')

    # Table 1: EU removal and reported UK milestones
    spec = [('Melli', 'melli_eu_delisting', [('PRA no-objection', 'pra_no_objection')]),
            ('Persia', 'persia_eu_delisting', [('PRA permission to resume normal business', 'persia_pra_2016')]),
            ('Sepah', 'sepah_eu_delisting', [('PRA letter', 'sepah_2016_19'), ('FCA confirmation', 'sepah_2017_20')]),
            ('Saderat', 'saderat_eu_expiry_2016', [('Confirmation to resume normal business', 'saderat_2018_15')])]
    body, delays = [], {}
    for bank, anchor, events in spec:
        texts, days = [], []
        for label, record in events:
            d = (exact(record) - exact(anchor)).days
            assert legal.at[record, 'comparison_anchor_date'] == exact(anchor).date().isoformat()
            assert d == int(legal.at[record, 'days_from_anchor_lower']) == int(legal.at[record, 'days_from_anchor_upper'])
            texts.append(f'{label}, {short(exact(record))}')
            days.append(d)
            delays[record] = d
        body.append(f"{bank} & {short(exact(anchor))} & {'; '.join(texts)} & {'; '.join(map(str, days))} " + r'\\')
    assert sorted(delays.values()) == [2, 97, 111, 296, 691]
    emit('DelayMin', WORDS.get(min(delays.values()), min(delays.values())), LEGAL, 'Table 1 delays', 'minimum over five milestones')
    emit('DelayMax', max(delays.values()), LEGAL, 'Table 1 delays', 'maximum over five milestones')
    assert (exact('saderat_2018_15') - (sad + pd.Timedelta(days=1))).days == delays['saderat_2018_15'] - 1
    table = [r'\begin{table}[!htbp]', r'\centering\small',
             r'\caption{EU removal and reported UK supervisory milestones}', r'\label{tab:milestones}',
             r'\begin{tabularx}{\textwidth}{@{}l l Y r@{}}', r'\toprule',
             r'Bank & EU removal & Company-reported UK milestone & Days \\', r'\midrule', *body,
             r'\bottomrule', r'\end{tabularx}', r'\par\smallskip\footnotesize\raggedright',
             (f'Days are elapsed calendar days from the EU date. Starting Saderat on 23 October gives '
              f'{delays["saderat_2018_15"] - 1} days. The milestones refer to different constraints, and Persia\'s '
              f'date comes from a retrospective disclosure. PRA: Prudential Regulation Authority; '
              f'FCA: Financial Conduct Authority.'), r'\end{table}']
    (OUT / 'table_milestones.tex').write_text('\n'.join(table) + '\n')

    # Operational records outside the legal ledger
    ops = pd.read_csv(ROOT / OPS).set_index('observation_id')
    assert pd.isna(ops.at['saderat_2017_14', 'date_lower'])
    emit('SaderatReviewBy', my(pd.Timestamp(ops.at['saderat_2017_14', 'date_upper'])), OPS,
         'saderat_2017_14 upper bound', 'regulators still reviewing at that date')

    # Bank accounts
    panel = pd.read_csv(ROOT / PANEL, parse_dates=['fiscal_end'])
    e = pd.read_csv(ROOT / ENDPOINTS).set_index('bank')
    pre = {}
    for bank, g in panel.groupby('bank'):
        base = g[g.fiscal_year.eq(2015)].iloc[0]
        last = g[g.fiscal_end.lt(withdrawal)].sort_values('fiscal_end').iloc[-1]
        assert last.fiscal_end.date().isoformat() == e.at[bank, 'last_fiscal_endpoint_before_us_withdrawal']
        pre[bank] = (base, last)
    names = {'melli': 'Melli', 'persia': 'Persia', 'saderat': 'Saderat', 'sepah': 'Sepah'}
    for bank, label in names.items():
        r_pre = e.at[bank, 'loan_stock_last_pre_pct_of_2015']
        r_chk = e.at[bank, 'loan_stock_2017_pct_of_2015']
        base, last = pre[bank]
        assert abs(100 * last.loans_advances_customers / base.loans_advances_customers - r_pre) < 1e-8
        emit(f'Loan{label}Pre', f'{r_pre:.0f}', ENDPOINTS, f'{bank} loan_stock_last_pre_pct_of_2015', 'recomputed from panel')
        emit(f'Loan{label}Check', f'{r_chk:.0f}', ENDPOINTS, f'{bank} loan_stock_2017_pct_of_2015', 'below 100')
        assert r_pre < 100 and r_chk < 100
        s0, s1 = e.at[bank, 'loan_stock_share_2015'], e.at[bank, 'loan_stock_share_last_pre']
        assert s1 < s0
        if bank in ('persia', 'saderat'):
            emit(f'Share{label}Base', f'{s0:.1f}', ENDPOINTS, f'{bank} loan_stock_share_2015', 'share of assets, percent')
            emit(f'Share{label}Pre', f'{s1:.1f}', ENDPOINTS, f'{bank} loan_stock_share_last_pre', 'lower than 2015')
    order = e.loan_stock_last_pre_pct_of_2015.sort_values()
    assert list(order.index) == ['persia', 'sepah', 'melli', 'saderat']
    # Profit and administrative expenses at the same endpoints
    turned = sorted(b for b, (x, y) in pre.items() if x.profit_after_tax > 0 > y.profit_after_tax)
    assert turned == ['melli', 'persia', 'sepah']
    assert pre['saderat'][0].profit_after_tax > 0 and pre['saderat'][1].profit_after_tax > 0
    up = sorted(b for b, (x, y) in pre.items() if y.administrative_expenses > x.administrative_expenses)
    assert up == ['melli', 'persia', 'sepah']
    # Liquid assets: cash and loans and advances to banks
    for bank, label in names.items():
        x, y = pre[bank]
        emit(f'Banks{label}Base', eur_m(x.loans_advances_banks), PANEL, f'{bank} loans_advances_banks 2015', 'EUR million')
        emit(f'Banks{label}Pre', eur_m(y.loans_advances_banks), PANEL, f'{bank} loans_advances_banks last pre', 'EUR million')
        if bank != 'saderat':
            emit(f'Cash{label}Base', eur_m(x.cash_reported), PANEL, f'{bank} cash_reported 2015', 'EUR million')
            emit(f'Cash{label}Pre', eur_m(y.cash_reported), PANEL, f'{bank} cash_reported last pre', 'EUR million')
    for bank in ('persia', 'sepah'):
        x, y = pre[bank]
        assert y.loans_advances_banks > 5 * x.loans_advances_banks and y.cash_reported < x.cash_reported
    paired = [name for name, (base, last) in pre.items()
              if last.loans_advances_banks > base.loans_advances_banks and last.cash_reported < base.cash_reported]
    assert sorted(paired) == ['persia', 'sepah']
    check_year = panel.loc[panel.fiscal_year.eq(2017)].set_index('bank')
    assert check_year.index.is_unique and set(check_year.index) == set(pre)
    for name, (base, last) in pre.items():
        keeper = check_year.loc[name]
        for line in ('loans_advances_banks', 'cash_reported'):
            assert (keeper[line] > base[line]) == (last[line] > base[line])
            assert (keeper[line] < base[line]) == (last[line] < base[line])
    emit('ShiftBankCount', WORDS[len(paired)], PANEL,
         'loans_advances_banks and cash_reported, 2015, 2017 and latest pre-withdrawal observations',
         'Both endpoints show higher bank advances and lower cash at Persia and Sepah. Within-bank positions only.')
    x, y = pre['melli']
    assert y.loans_advances_banks < x.loans_advances_banks and y.cash_reported > x.cash_reported
    x, y = pre['saderat']
    assert abs(y.loans_advances_banks / x.loans_advances_banks - 1) < 0.10
    # Section 6.1: changes from the base endpoint in cash, advances to banks, their sum and customer loans
    check_line = [l for l in (OUT / 'paper_claims.tex').read_text().splitlines() if l.startswith(r'\newcommand{\CheckYear}')]
    check_year = int(re.fullmatch(r'\\newcommand\{\\CheckYear\}\{(\d{4})\}', check_line[0]).group(1))
    base_year = int(pre['persia'][0].fiscal_year)
    assert all(int(pre[b][0].fiscal_year) == base_year for b in names)
    last = {b: int(pre[b][1].fiscal_year) for b in names}
    assert last == {'persia': check_year + 1, 'sepah': check_year + 1, 'melli': check_year, 'saderat': check_year}
    yearly = panel.set_index(['bank', 'fiscal_year'])
    def change(bank, year):
        x, y = yearly.loc[(bank, base_year)], yearly.loc[(bank, year)]
        d = {k: y[k] - x[k] for k in ('cash_reported', 'loans_advances_banks', 'loans_advances_customers')}
        d['sum'] = d['cash_reported'] + d['loans_advances_banks']
        d['end'] = y.fiscal_end
        return d
    rows_c = [(names[b], b, yr) for b in ('persia', 'sepah', 'melli', 'saderat') for yr in sorted({check_year, last[b]})]
    comp = {(b, yr): change(b, yr) for _, b, yr in rows_c}
    pa, pb = comp[('persia', check_year)], comp[('persia', last['persia'])]
    sa, sb = comp[('sepah', check_year)], comp[('sepah', last['sepah'])]
    assert pa['loans_advances_banks'] > -pa['cash_reported'] > 0          # Persia: advances already offset cash
    assert -sa['cash_reported'] > sa['loans_advances_banks'] > 0          # Sepah: cash fall still larger
    assert 0 < pb['sum'] < 0.05 * -pb['cash_reported']                     # Persia pre: advances slightly exceed
    assert 0.8 < sb['loans_advances_banks'] / -sb['cash_reported'] < 1    # Sepah pre: advances cover most of it
    m = comp[('melli', check_year)]; assert m['loans_advances_banks'] < 0 < m['cash_reported']
    d = comp[('saderat', check_year)]; assert d['loans_advances_banks'] < 0 and d['cash_reported'] < 0
    assert all(v['loans_advances_customers'] < 0 for v in comp.values())
    stamp = lambda v: f"{ABBR[v['end'].month]} {v['end'].year}"
    lines = pd.read_csv(ROOT / FIN)
    def described(measure):
        sub = lines[lines.measure == measure]
        assert sub.groupby('bank').source_label.nunique().eq(1).all() and set(sub.bank) == set(names)
        return '; '.join(f"{lab[0].lower()}{lab[1:]} ({', '.join(sorted(names[k] for k in banks))})"
                         for lab, banks in sub.groupby('source_label').bank.unique().items())
    num = lambda x: f'{x:.1f}'.replace('-', r'\ensuremath{-}')
    body_c = [f"{lab} & {stamp(comp[(b, yr)])} & " + ' & '.join(num(comp[(b, yr)][k]) for k in
              ('cash_reported', 'loans_advances_banks', 'sum', 'loans_advances_customers')) + r' \\' for lab, b, yr in rows_c]
    note = (f"Changes between the {base_year} fiscal endpoint and the endpoint shown; sums use unrounded amounts. "
            f"{stamp(pa)} and {stamp(m)} are the endpoints labelled {check_year}; {stamp(pb)} and {stamp(comp[('melli', last['melli'])])} "
            r"are the last endpoints before \WithdrawalDate{}. Cash is the reported line: " + described('cash_reported') +
            '. Advances to banks: ' + described('loans_advances_banks') + '.')
    table_c = [r'\begin{table}[!htbp]', r'\centering\small',
               rf'\caption{{Changes from the {base_year} endpoint in liquid assets and customer loans (EUR million)}}',
               r'\label{tab:balance-composition}', r'\begin{tabular}{@{}llrrrr@{}}', r'\toprule',
               r'Bank & Endpoint & Cash & Advances to banks & Cash plus advances & Customer loans \\', r'\midrule', *body_c,
               r'\bottomrule', r'\end{tabular}', r'\par\smallskip\footnotesize\raggedright', note, r'\end{table}']
    (OUT / 'table_balance_composition.tex').write_text('\n'.join(table_c) + '\n')
    emit('PreEndMarch', my(pre['persia'][1].fiscal_end), PANEL, 'persia and sepah last pre fiscal_end', 'common date')
    assert pre['persia'][1].fiscal_end == pre['sepah'][1].fiscal_end
    emit('PreEndDecember', my(pre['melli'][1].fiscal_end), PANEL, 'melli and saderat last pre fiscal_end', 'common date')
    assert pre['melli'][1].fiscal_end == pre['saderat'][1].fiscal_end
    # Melli carrying-value reconciliation (EUR thousand in source)
    recon = pd.read_csv(ROOT / RECON).sort_values('fiscal_year')
    assert len(recon) == 2
    for _, r in recon.iterrows():
        assert r.gross_customer_loans_eur_thousand - r.impairment_provision_eur_thousand == r.net_customer_loans_eur_thousand
    (g0, g1), (p0, p1), (n0, n1) = (recon[c].to_numpy() / 1000 for c in (
        'gross_customer_loans_eur_thousand', 'impairment_provision_eur_thousand', 'net_customer_loans_eur_thousand'))
    assert g1 > g0 and p1 > p0 and n1 < n0
    for name, v in [('MelliGrossA', g0), ('MelliGrossB', g1), ('MelliProvA', p0), ('MelliProvB', p1),
                    ('MelliNetA', n0), ('MelliNetB', n1)]:
        emit(name, f'EUR{v:.3f} million', RECON, name, 'gross less provision equals net')
    emit('MelliReconA', f'December {int(recon.fiscal_year.iloc[0])}', RECON, 'fiscal_year', 'December year-end')
    emit('MelliReconB', f'December {int(recon.fiscal_year.iloc[1])}', RECON, 'fiscal_year', 'December year-end')
    # Persia commissions and fee income (EUR thousand in source)
    fin = pd.read_csv(ROOT / FIN)
    pf = fin[fin.bank.eq('persia')].set_index(['fiscal_year', 'measure'])
    for yr, tag in ((2017, 'A'), (2018, 'B')):
        cost, gross = pf.at[(yr, 'fee_cost'), 'value_original'], pf.at[(yr, 'fee_gross'), 'value_original']
        assert pf.at[(yr, 'fee_cost'), 'value_status'] == 'observed' and cost > gross
        emit(f'PersiaComm{tag}', eur_k(cost), FIN, f'persia {yr} fee_cost', 'observed; exceeds fee income')
        emit(f'PersiaFee{tag}', eur_k(gross), FIN, f'persia {yr} fee_gross', 'observed')
        end = panel[panel.bank.eq('persia') & panel.fiscal_year.eq(yr)].fiscal_end.iloc[0]
        assert end.month == 3
        emit(f'PersiaYear{tag}', my(end), PANEL, f'persia {yr} fiscal_end', 'March year-end')
    # Panel coverage
    assert len(fin) == 128 and fin.value_eur.notna().sum() == 100
    missing = fin[fin.value_eur.isna()]
    assert missing.measure.str.startswith('fee_').all() and missing.value_status.eq('not_separately_extracted').all()
    emit('PanelCells', len(fin), FIN, 'all rows', '16 statements by eight measures')
    emit('PanelObserved', int(fin.value_eur.notna().sum()), FIN, 'value_eur not missing', 'count')
    emit('PanelMissing', len(missing), FIN, 'value_eur missing', 'all fee components, none set to zero')

    # BIS positions
    ann = pd.read_csv(ROOT / ANNUAL)
    f = ann[ann.measure.str.startswith('sum')].set_index(['series', 'year']).value
    s = ann[ann.measure.str.startswith('q4')].set_index(['series', 'year']).value

    def bis(macro, value, cell, sign):
        assert (value > 0) if sign > 0 else (value < 0), (macro, value)
        emit(macro, usd(value), ANNUAL, cell, 'positive' if sign > 0 else 'negative')

    bis('LiabBanks', f['liabilities_banks', 2016], 'liabilities_banks 2016', 1)
    assert f['liabilities_banks', 2016] > f['liabilities_total', 2016]
    bis('LiabNonBanksFall', f['liabilities_nonbanks', 2016], 'liabilities_nonbanks 2016', -1)
    bis('LiabLoansDeposits', f['liabilities_loan_deposits', 2016], 'liabilities_loan_deposits 2016', 1)
    bis('LiabEUR', f['liabilities_eur', 2016], 'liabilities_eur 2016', 1)
    assert f['liabilities_eur', 2016] > f['liabilities_total', 2016]
    bis('LiabFallNext', f['liabilities_total', 2017], 'liabilities_total 2017', -1)
    bis('LiabCum', f['liabilities_total', 2016] + f['liabilities_total', 2017], 'liabilities_total 2016+2017', 1)
    bis('ClaimsCumFall', f['claims_total', 2016] + f['claims_total', 2017], 'claims_total 2016+2017', -1)
    bis('ClaimsFallNext', f['claims_total', 2017], 'claims_total 2017', -1)
    for macro, yr in (('ClaimsStockBase', 2015), ('ClaimsStockRelief', 2016), ('ClaimsStockNext', 2017)):
        bis(macro, s['claims_total', yr], f'claims_total {yr}Q4 stock', 1)
    assert s['claims_total', 2015] > s['claims_total', 2016] > s['claims_total', 2017]
    emit('NextYear', 2017, ANNUAL, 'year', 'calendar year after relief')
    # Section 6.2: one-number summaries of the two sides
    c16, l16 = f['claims_total', 2016], f['liabilities_total', 2016]
    c17, l17 = f['claims_total', 2017], f['liabilities_total', 2017]
    assert l16 > -c16 > 0  # the liability rise more than offsets the fall in claims
    bis('BISSumRelief', c16 + l16, 'claims_total + liabilities_total 2016', 1)
    bis('BISNetReliefFall', c16 - l16, 'claims_total - liabilities_total 2016', -1)
    bis('BISSumTwoYearFall', c16 + l16 + c17 + l17, 'claims + liabilities, 2016 and 2017', -1)
    bis('BISNetTwoYearFall', c16 - l16 + c17 - l17, 'claims - liabilities, 2016 and 2017', -1)
    q = pd.read_csv(ROOT / QUARTERLY)
    q1 = q[q.series.eq('liabilities_total') & q.L_MEASURE.eq('F') & q.quarter.eq('2016Q1')].OBS_VALUE
    assert len(q1) == 1
    bis('LiabQOne', q1.iloc[0], 'liabilities_total 2016Q1', 1)
    signs = q[q.series.eq('liabilities_total') & q.L_MEASURE.eq('F') & q.quarter.str.startswith('2016')]
    assert (signs.sort_values('quarter').OBS_VALUE.gt(0).tolist() == [True, False, True, False])  # appendix wording
    rep = pd.read_csv(ROOT / REPORTERS).set_index(['reporter', 'year'])

    def r(code, col='annual', year=2016):
        v = rep.at[(code, year), col]
        assert pd.notna(v), (code, year, col)
        return v

    def rmac(macro, code, col, year, sign):
        v = r(code, col, year)
        assert (v > 0) if sign > 0 else (v < 0), (macro, v)
        emit(macro, usd(v), REPORTERS, f'{code} {year} {col}', 'positive' if sign > 0 else 'negative')

    rmac('DELiab', 'DE', 'annual', 2016, 1)
    rmac('DELiabQOne', 'DE', 'q1', 2016, 1)
    rmac('DELiabNext', 'DE', 'annual', 2017, 1)
    rmac('GBLiab', 'GB', 'annual', 2016, 1)
    assert abs(r('GB')) < 0.01 * r('5A')
    outside_de = r('5A') - r('DE')
    assert 0 < outside_de < r('DE')
    emit('DEExcludedLiab', r'\$' + f'{outside_de:.0f} million',
         REPORTERS, '5A annual less DE annual, 2016',
         'Positive arithmetic remainder, including unpublished or coverage residual.')
    joint_remainder = outside_de - (r('5A', 'q1') - r('DE', 'q1'))
    assert joint_remainder < 0
    emit('DEAndQuarterExcludedFall', r'\$' + f'{abs(joint_remainder):.0f} million',
         REPORTERS, '(5A minus DE) annual minus (5A minus DE) q1, 2016',
         'Negative arithmetic remainder when both Germany and the first quarter are excluded.')
    rmac('ResidQOne', 'residual', 'q1', 2016, 1)
    rmac('ResidYearFall', 'residual', 'annual', 2016, -1)
    disclosed = rep.xs(2016, level='year').drop(index=['residual', '5A'])
    assert r('DE') == disclosed.annual.max() and r('KR') == disclosed.annual.min()
    assert r('DE') > 0.5 * r('5A')
    emit('ReporterCount', len(disclosed), REPORTERS, 'reporters with a bilateral series', 'count')

    # Trade finance in the filings (Section 4). Melli's undrawn commitments are transcribed from note 17 (2017 filing,
    # PDF p. 29) and note 18 (2018 filing, PDF p. 33) and were checked against the filed pages; each row is tied to
    # the hashed filing in the download manifest. The prose statements rest on the evidence register.
    manifest = json.loads((ROOT / MANIFEST).read_text())
    by_hash = {row['sha256']: row for row in manifest}
    commitments = pd.read_csv(ROOT / COMMITMENTS).set_index(['filing_year', 'fiscal_end'])
    assert commitments.index.is_unique
    assert len(commitments) == 4 and commitments.notna().all().all()  # missing is not zero: all four cells observed
    assert commitments.checked_against_pdf.str.fullmatch(r'\d{4}-\d{2}-\d{2}').all()  # each cell read on the filed page
    for year, page in ((2017, 29), (2018, 33)):
        filed, = (row for row in manifest if row['bank'] == 'melli' and row['year'] == year)
        cells = commitments.loc[year]
        assert len(cells) == 2 and cells.sha256.eq(filed['sha256']).all() and cells.source_url.eq(filed['url']).all()
        assert cells.pdf_page.eq(page).all()
    start = commitments.at[(2017, '2016-12-31'), 'undrawn_commitments_eur']
    pre_c = commitments.at[(2017, '2017-12-31'), 'undrawn_commitments_eur']
    post_c = commitments.at[(2018, '2018-12-31'), 'undrawn_commitments_eur']
    assert start == 0 < pre_c == commitments.at[(2018, '2017-12-31'), 'undrawn_commitments_eur'] < post_c
    assert commitments.loc[2017].measure.iat[0] != commitments.loc[2018].measure.iat[0]  # 2018 line adds discounting
    assert pd.Timestamp('2017-12-31') < withdrawal < pd.Timestamp('2018-12-31')
    emit('MelliCommitmentStart', 'nil', COMMITMENTS, '2017 filing, 2016-12-31',
         'Explicit zero in the filing, not a missing value; refinancing only.')
    emit('MelliCommitmentPre', eur_m(pre_c / 1e6), COMMITMENTS, '2017 filing, 2017-12-31',
         'Before the withdrawal announcement; the 2018 filing repeats the amount as its comparator.')
    emit('MelliCommitmentPost', eur_m(post_c / 1e6), COMMITMENTS, '2018 filing, 2018-12-31',
         'Broader line including discounting, after the withdrawal announcement.')
    melli = panel[panel.bank.eq('melli')].set_index('fiscal_end').loans_advances_customers
    earlier, later = melli[pd.Timestamp('2016-12-31')], melli[pd.Timestamp('2017-12-31')]
    assert 0 < later < earlier and abs(later - n0) < 5e-4  # panel (2017 filing) equals note 7 of the 2018 filing
    emit('MelliLoansEarlier', f'EUR{earlier:.3f} million', PANEL, 'melli 2016-12-31 loans_advances_customers',
         'Same endpoints as the commitments; the 2017 value equals MelliNetA.')
    register = pd.read_csv(ROOT / REGISTER)
    assert register.checked_against_pdf.notna().all()  # every statement read on the filed page
    for row in register.itertuples():
        filed = by_hash[row.sha256]
        assert filed['bank'] == row.bank and filed['url'] == row.source_url and str(row.pdf_page).strip(), row
    print(f'Trade-finance evidence: {len(commitments)} commitment cells and {len(register)} register rows tied to '
          f'{register.sha256.nunique()} hashed filings')

    # Crosswalk and timing classes (appendix)
    xr = pd.read_csv(ROOT / CROSSWALK).set_index('check').value
    assert xr['iran_formal_terminations_2016'] == 0 and xr['iran_lifting_pulses_2015_2018'] == 0
    timing = pd.read_csv(ROOT / TIMING).set_index('relative_year_class').milestone_count
    assert timing.sum() == 5 and timing['t'] == 4 and timing['later'] == 1 and timing.drop(['t', 'later']).eq(0).all()
    emit('TimingSameYear', WORDS[int(timing['t'])], TIMING, 't', 'four of five')

    (OUT / 'body_claims.tex').write_text(''.join(r'\newcommand{\%s}{%s}' % (v['macro'], v['display']) + '\n'
                                                 for v in rows))
    with (OUT / 'body_claim_ledger.csv').open('w', newline='') as fh:
        w = csv.DictWriter(fh, fieldnames=rows[0].keys())
        w.writeheader()
        w.writerows(rows)
    print(f'{len(rows)} body macros written')


if __name__ == '__main__':
    main()

from pathlib import Path
import json,csv
ROOT=Path(__file__).resolve().parent
P=ROOT.parent
reports={(r['bank'],r['year']):r for r in json.loads((ROOT/'report_download_manifest.json').read_text())}
meta=json.loads((ROOT/'financial_transcription.json').read_text())['banks']
old=json.loads((P/'evidence_20261114/paper2/legal_reopening/operational/operational_events.json').read_text())
rows=[]
def add(bank,year,page,kind,lo,hi,event,note,precision='exact_day'):
 r=reports[bank,year]
 rows.append(dict(observation_id=f'{bank}_{year}_{len(rows)+1:02}',bank=bank,entity_scope=meta[bank]['entity'],kind=kind,
  date_lower=lo,date_upper=hi,date_precision=precision,event=event,qualification=note,
  source_id=f'{bank}_accounts_{year}',source_url=r['url'],source_sha256=r['sha256'],pdf_page=page,
  report_approval_date=meta[bank]['financials'][str(year)]['approval_date'],
  authority_independently_confirmed=False,first_executed_customer_transaction_verified=False))
add('melli',2018,5,'reported_executed_activity','2018-01-01','2018-12-31','Letters of credit advised, refinanced and discounted during 2018','Company reports completed activity; no transaction amounts, dates or customer identities. Separate from project finance still in pipeline.','calendar_year')
add('melli',2018,4,'reported_operational_interruption','2018-11-01','2018-11-30','SWIFT withdrawal reportedly interrupted TARGET2 use','Bank attributes interruption to loss of messaging; this does not establish loss of the underlying TARGET2 account.','month')
add('melli',2018,4,'reported_operational_access',None,'2019-04-25','Alternative internet access to Bundesbank TARGET2 account reportedly restored euro payments','No exact date; report approval is upper disclosure bound.','report_bound')
add('persia',2015,5,'reported_pre_state','2014-04-01','2015-03-31','Legacy corporate and trade-finance bank with new trade finance ceased since July 2011','Prior business model, not evidence of post-relief activity.','fiscal_period')
add('persia',2016,5,'reported_legal_event','2016-01-16','2016-01-16','EU sanctions lifting reported','Corroborated separately by Regulation2015/1862 and application notice; retained here as issuer statement.')
add('persia',2016,5,'reported_operational_access','2016-06-01','2016-06-30','TARGET2 participation through Deutsche Bundesbank','In report issued July2016, after fiscal endpoint; not assigned to31March2016.','month')
add('persia',2017,3,'reported_constraint',None,'2017-06-23','Sterling clearing unavailable and Dubai branch inactive','Current state reported by chairman; no exact start date for every constraint.','report_bound')
add('persia',2017,6,'reported_executed_activity','2016-04-01','2017-03-31','Euro transfer commission recorded as EUR156000','Narrative attributes entire fee-payable line to a euro transfer; fee is not transfer principal.','fiscal_period')
add('persia',2018,4,'reported_executed_activity','2017-04-01','2018-03-31','Small fee income from trade-finance activity reported','No gross financing volume; does not imply full resumption of ordinary banking.','fiscal_period')
add('persia',2018,4,'reported_executed_activity','2017-04-01','2018-03-31','Euro transfer commission recorded as EUR219000','Narrative attributes entire fee-payable line to a euro transfer; fee is not transfer principal.','fiscal_period')
add('saderat',2015,7,'reported_pre_state','2015-01-01','2015-12-31','New business restricted; legacy collections and licensed activity continued','Restriction does not imply zero activity.','calendar_year')
add('saderat',2016,7,'reported_legal_event','2016-10-22','2016-10-22','EU asset-freeze removal reported','Bank and parliamentary report use22October; implementing act limits entry until22October. One-day legal-boundary sensitivity remains available.')
add('saderat',2016,7,'reported_regulatory_constraint',None,'2017-04-20','New business remained subject to regulatory permission','June2017 reopening was an expectation in the report, not an observed opening.','report_bound')
add('saderat',2017,7,'reported_regulatory_constraint',None,'2018-03-08','Regulators still reviewing resumption plan','Expected second-quarter2018 reopening is not coded as realised.','report_bound')
add('saderat',2018,6,'reported_regulatory_permission','2018-09-13','2018-09-13','Regulatory confirmation to resume normal business reportedly received','Company report identifies date; original regulatory letter not acquired.')
add('sepah',2015,4,'reported_pre_state','2014-04-01','2015-03-31','No new business under UN sanctions; licensed legacy receipts and payments','Pre-relief description; continuing receipts do not establish new loans.','fiscal_period')
add('sepah',2016,4,'reported_legal_event','2016-01-17','2016-01-17','UN delisting reported','Corroborated separately by UN noticeSC/12209 and EU Regulation2016/74.')
add('sepah',2016,4,'reported_legal_event','2016-01-23','2016-01-23','EU delisting reported','Corroborated by Regulation2016/74 publication and commencement on23January.')
add('sepah',2016,4,'reported_regulatory_permission','2016-04-29','2016-04-29','PRA no-objection letter reported','Original regulatory letter not acquired; timing independently repeated in following annual report.')
add('sepah',2017,4,'reported_regulatory_permission','2016-05-13','2016-05-13','FCA no-objection confirmation reported','Original regulatory letter not acquired.')
add('sepah',2017,4,'reported_operational_access','2016-10-01','2016-10-31','Direct TARGET2 participation through Deutsche Bundesbank','Month precision only.','month')
add('sepah',2017,4,'reported_operational_access','2016-04-01','2017-03-31','New eurozone correspondent relationships for euro and Swiss-franc clearing','No named correspondents, exact dates or relationship counts.','fiscal_period')
add('sepah',2018,4,'reported_executed_activity','2017-01-01','2017-12-31','First international payments and trade transactions after reactivation reported','Company explicitly says2017; no day, amount or underlying transaction record.','calendar_year')
add('sepah',2018,4,'reported_operational_access','2017-04-01','2018-03-31','Legacy accounts reactivated with new KYC and new customers onboarded','Reporting-period bound; no individual onboarding dates or customer counts.','fiscal_period')
combined=[]
for x in old:combined.append({**x,'bank':'melli'})
combined+=rows
(ROOT/'operational_extension.json').write_text(json.dumps(rows,indent=2))
(ROOT/'operational_events_all.json').write_text(json.dumps(combined,indent=2))
fields=list(dict.fromkeys(k for r in combined for k in r))
with (ROOT/'operational_events_all.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(combined)
print('Existing records',len(old),'new records',len(rows),'combined',len(combined))

"""Rebuild the four-bank descriptive panel from visually checked transcriptions.

No bank selection, winsorisation, regression or causal effect is computed here.
"""
from pathlib import Path
from datetime import date
import json,hashlib,csv
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.dates as mdates

ROOT=Path(__file__).resolve().parent
PROGRAMME=ROOT.parent
INPUT=ROOT/'financial_transcription.json'
DATA=json.loads(INPUT.read_text())
manifest_path=ROOT/'report_download_manifest.json'
if not manifest_path.exists():
 raise FileNotFoundError('Copy the archived source manifest into this folder first')
MANIFEST=json.loads(manifest_path.read_text())
LOOKUP={(r['bank'],int(r['year'])):r for r in MANIFEST if r['status']=='acquired'}
assert len(LOOKUP)==16
rows=[]
for bank,meta in DATA['banks'].items():
 for year,entry in meta['financials'].items():
  src=LOOKUP[bank,int(year)]
  for measure,value in list(zip(DATA['measurement_order'],entry['values']))+[(k,entry[k]) for k in ['fee_gross','fee_cost','fee_net']]:
   statement='balance' if measure in DATA['measurement_order'][:3] else 'income'
   label={'cash_reported':meta['cash_label'],'loans_advances_banks':meta['bank_asset_label']}.get(measure,measure.replace('_',' '))
   rows.append(dict(bank=bank,entity=meta['entity'],company_number=meta['company_number'],fiscal_year=int(year),
    fiscal_end=f'{year}-{meta["fiscal_month_day"]}',measure=measure,source_label=label,currency='EUR',
    unit_multiplier=meta['multiplier'],value_original=value,
    value_eur=None if value is None else value*meta['multiplier'],
    value_eur_million=None if value is None else value*meta['multiplier']/1e6,
    value_status='observed' if value is not None else 'not_separately_extracted',
    pdf_page=entry[statement+'_pdf_page'],printed_page=entry[statement+'_printed_page'],
    statement_approval_date=entry['approval_date'],source_url=src['url'],source_sha256=src['sha256'],source_filename=src['file'],
    measurement_type='stock' if statement=='balance' else 'annual_income_statement',
    source_scope='Entity-wide; no inference of borrower country or new originations',visually_verified=value is not None))
df=pd.DataFrame(rows)
assert len(df)==128 and df.value_eur.notna().sum()==100
assert not df.duplicated(['bank','fiscal_year','measure']).any()
df.to_csv(ROOT/'bank_financial_panel.csv',index=False)
(ROOT/'bank_financial_panel.json').write_text(json.dumps(rows,indent=2))
common=df[df.measure.isin(DATA['measurement_order'])]
assert common.value_eur.notna().all() and len(common)==80
wide=common.pivot(index=['bank','entity','fiscal_year','fiscal_end'],columns='measure',values='value_eur_million').reset_index()
print('bank panel populated cells:', wide[list(DATA['measurement_order'])].count().to_dict())
assert len(wide) == 16 and wide[list(DATA['measurement_order'])].count().eq(16).all()
wide.to_csv(ROOT/'bank_year_panel.csv',index=False)
summary=[]
for bank,g in wide.groupby('bank',sort=False):
 g=g.sort_values('fiscal_year');a=g[g.fiscal_year==2015].iloc[0];b=g[g.fiscal_year==2018].iloc[0]
 summary.append(dict(bank=bank,entity=b.entity,loans_2015_eur_million=a.loans_advances_customers,
  loans_2017_eur_million=g[g.fiscal_year==2017].iloc[0].loans_advances_customers,
  loans_2018_eur_million=b.loans_advances_customers,
  customer_loans_2018_pct_2015=100*b.loans_advances_customers/a.loans_advances_customers,
  expenses_2015_eur_million=a.administrative_expenses,expenses_2018_eur_million=b.administrative_expenses,
  expenses_2018_pct_2015=100*b.administrative_expenses/a.administrative_expenses))
pd.DataFrame(summary).to_csv(ROOT/'bank_comparison_summary.csv',index=False)

plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.spines.top':False,'axes.spines.right':False,'savefig.bbox':'tight'})
fig,axs=plt.subplots(1,2,figsize=(10,3.5),sharex=True)
styles={'melli':('#1b4965','o'),'persia':('#a94833','s'),'saderat':('#43866b','^'),'sepah':('#755392','D')}
for bank,g in wide.groupby('bank',sort=False):
 g=g.sort_values('fiscal_year');color,marker=styles[bank];x=pd.to_datetime(g.fiscal_end)
 for ax,m in zip(axs,['loans_advances_customers','administrative_expenses']):
  vals=100*g[m]/g[g.fiscal_year==2015][m].iloc[0]
  ax.plot(x,vals,color=color,marker=marker,linewidth=1.7,label=bank.capitalize())
for ax,title in zip(axs,['Customer loans','Administrative expenses']):
 ax.set_title(title,loc='left',fontsize=11);ax.axhline(100,color='#777777',linewidth=.7,linestyle=':')
 ax.axvline(pd.Timestamp('2016-01-16'),color='#777777',linewidth=.8,linestyle='--')
 ax.axvline(pd.Timestamp('2018-05-08'),color='#999999',linewidth=.8,linestyle='-.')
 ax.set_ylabel('Own 2015 fiscal endpoint = 100')
 ax.xaxis.set_major_locator(mdates.YearLocator());ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y'))
 ax.grid(axis='y',alpha=.15)
axs[1].legend(frameon=False,loc='upper left',ncol=2)
fig.tight_layout();fig.savefig(ROOT/'bank_balance_sheet_paths.pdf');fig.savefig(ROOT/'bank_balance_sheet_paths.png',dpi=180);plt.close(fig)

def fmt(x):return f'{x:.3f}'
tex=[r'\begin{table}[!ht]\centering\small',r'\caption{Customer lending and operating costs across four banks}\label{tab:fourbanks}',r'\begin{tabular}{lrrrrr}\toprule',r' & \multicolumn{3}{c}{Customer loans, EUR million} & \multicolumn{2}{c}{2018 as \% of 2015}\\',r'Bank & 2015 & 2017 & 2018 & Loans & Expenses\\\midrule']
for s in summary:tex.append(f"{s['bank'].capitalize()} & {fmt(s['loans_2015_eur_million'])} & {fmt(s['loans_2017_eur_million'])} & {fmt(s['loans_2018_eur_million'])} & {s['customer_loans_2018_pct_2015']:.1f} & {s['expenses_2018_pct_2015']:.1f} "+r'\\')
tex +=[r'\bottomrule\end{tabular}',r'\par\smallskip\begin{minipage}{0.97\linewidth}\footnotesize Source: current-year columns in 16 filed annual reports. Fiscal years end in March for Persia and Sepah, and December for Melli and Saderat. Customer loans are carrying values, not new lending. Expenses are the separately reported administrative line, with differences in accounting presentation retained. Ratios are within-bank comparisons; no pooled common-treatment effect is estimated.\end{minipage}',r'\end{table}']
(ROOT/'bank_comparison_table.tex').write_text('\n'.join(tex))
out=dict(frame_banks=4,bank_years=16,financial_observed_values=100,common_measure_values=80,unextracted_fee_slots=28,
 transcription_sha256=hashlib.sha256(INPUT.read_bytes()).hexdigest(),summary=summary,
 reported_intervals_days={'melli_uk_20160116_to_pra_20160118':(date(2016,1,18)-date(2016,1,16)).days,
 'sepah_eu_20160123_to_pra_20160429':(date(2016,4,29)-date(2016,1,23)).days,
 'sepah_eu_20160123_to_fca_20160513':(date(2016,5,13)-date(2016,1,23)).days,
 'saderat_reported_eu_20161022_to_regulatory_20180913':(date(2018,9,13)-date(2016,10,22)).days},
 limitations=['Named frame, not an asserted census of all Iran-linked UK banking operations','No untreated group or causal interpretation','Fiscal endpoints differ','No gross origination or country allocation','Administrative costs do not isolate compliance costs','Bank narrative is separately attributed from audited financial statements'])
(ROOT/'results_summary.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))

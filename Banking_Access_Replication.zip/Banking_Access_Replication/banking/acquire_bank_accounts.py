from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import urllib.request, urllib.parse, json, hashlib, re
from bs4 import BeautifulSoup

BASE=Path(__file__).resolve().parent
OUT=BASE/'downloaded_reports';OUT.mkdir(parents=True,exist_ok=True)
HOST='https://find-and-update.company-information.service.gov.uk'
BANKS={'melli':'04152338','persia':'04218020','sepah':'04189598','saderat':'01126618'}
def get(url,path):
 if not path.exists():
  req=urllib.request.Request(url,headers={'User-Agent':'Academic research source retrieval'})
  with urllib.request.urlopen(req,timeout=35) as r:
   content=r.read()
  path.write_bytes(content)
 return path.read_bytes()
def index(item):
 bank,company=item;url=f'{HOST}/company/{company}/filing-history?category=accounts'
 rec={'bank':bank,'company_number':company,'index_url':url,'accessed_utc':datetime.now(timezone.utc).isoformat()}
 try:
  docs=[];pages=[];seen=set()
  for page in range(1,9):
   purl=url if page==1 else url+f'&page={page}'
   raw=get(purl,OUT/(bank+('_accounts_index.html' if page==1 else f'_accounts_index_p{page}.html')))
   s=BeautifulSoup(raw,'html.parser');old=False
   pages.append(dict(url=purl,sha256=hashlib.sha256(raw).hexdigest()))
   for tr in s.select('tr'):
    desc=' '.join(tr.get_text(' ',strip=True).split())
    am=re.search(r'accounts made up to (\d{1,2}\s+\w+\s+(\d{4}))',desc,re.I)
    if am and int(am[2])<2015:old=True
    m=re.search(r'accounts made up to (\d{1,2}\s+\w+\s+(201[5-8]))',desc,re.I)
    if not m:continue
    a=next((a for a in tr.find_all('a',href=True) if '/document?' in a['href']),None)
    if a is None:continue
    durl=urllib.parse.urljoin(HOST,a['href'])
    if durl in seen:continue
    seen.add(durl);token=hashlib.sha256(durl.encode()).hexdigest()[:10]
    docs.append(dict(bank=bank,company_number=company,fiscal_date_text=m[1],year=int(m[2]),description=desc,
                     url=durl,file=f'{bank}_{m[2]}_{token}.pdf'))
   if old or s.select_one('#next-page') is None:break
  rec.update(status='acquired',pages=pages,documents=docs)
 except Exception as e:rec.update(status='failed',error=type(e).__name__+': '+str(e),documents=[])
 print(json.dumps({'bank':bank,'status':rec['status'],'years':[x['year'] for x in rec['documents']]}),flush=True)
 return rec
with ThreadPoolExecutor(max_workers=4) as pool:indices=list(pool.map(index,BANKS.items()))
(OUT/'index_manifest.json').write_text(json.dumps(indices,indent=2))
def download(rec):
 rec=dict(rec);rec['accessed_utc']=datetime.now(timezone.utc).isoformat()
 try:
  raw=get(rec['url'],OUT/rec['file'])
  if not raw.startswith(b'%PDF'):raise ValueError('Response is not a PDF')
  rec.update(status='acquired',bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
 except Exception as e:rec.update(status='failed',error=type(e).__name__+': '+str(e))
 print(json.dumps({k:v for k,v in rec.items() if k in ['bank','year','status','bytes','error']}),flush=True)
 return rec
with ThreadPoolExecutor(max_workers=4) as pool:
 docs=list(pool.map(download,[d for x in indices for d in x['documents']]))
(OUT/'report_download_manifest.json').write_text(json.dumps(docs,indent=2))

from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import fitz,subprocess,os,json,time

ROOT=Path(__file__).resolve().parent/'downloaded_reports'
OUT=ROOT/'ocr';OUT.mkdir(exist_ok=True)
ENV=os.environ.copy();ENV['OMP_THREAD_LIMIT']='1'
def one(task):
 f,i=task;p=OUT/f.stem;p.mkdir(exist_ok=True)
 dest=p/f'page_{i+1:02}.txt'
 if dest.exists():return f.stem,i+1
 with fitz.open(f) as d:png=d[i].get_pixmap(dpi=170).tobytes('png')
 r=subprocess.run(['tesseract','stdin','stdout','--psm','3'],input=png,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=ENV,check=True)
 dest.write_bytes(r.stdout)
 return f.stem,i+1
files=sorted(ROOT.glob('*.pdf'));tasks=[]
for f in files:
 with fitz.open(f) as d:tasks.extend((f,i) for i in range(min(26,len(d))))
start=time.time()
with ThreadPoolExecutor(max_workers=3) as pool:
 for n,res in enumerate(pool.map(one,tasks),1):
  if n%20==0:print(json.dumps(dict(pages=n,total=len(tasks),seconds=round(time.time()-start,1),last=res)),flush=True)
for f in files:
 pages=sorted((OUT/f.stem).glob('page_*.txt'))
 (OUT/(f.stem+'.txt')).write_text('\n\n'.join('### PDF PAGE '+str(int(p.stem.split('_')[-1]))+'\n'+p.read_text() for p in pages))
print('Completed '+str(len(tasks))+' pages',flush=True)
